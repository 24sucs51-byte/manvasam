const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/hover:border-emerald-300/g, 'hover:border-[#A0522D]/40');

fs.writeFileSync('src/App.tsx', content);
