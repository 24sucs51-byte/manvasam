const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/focus:ring-emerald-500/g, 'focus:ring-[#A0522D]/60');
content = content.replace(/from-emerald-500\/40/g, 'from-[#A0522D]/60');

fs.writeFileSync('src/App.tsx', content);
