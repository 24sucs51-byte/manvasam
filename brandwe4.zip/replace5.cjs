const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/hover:bg-\[#A0522D\]\/70/g, 'hover:bg-emerald-700');

fs.writeFileSync('src/App.tsx', content);
