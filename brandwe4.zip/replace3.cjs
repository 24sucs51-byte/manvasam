const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/via-emerald-50/g, 'via-[#A0522D]/10');
content = content.replace(/divide-emerald-50/g, 'divide-[#A0522D]/10');
content = content.replace(/to-emerald-200\/50/g, 'to-[#A0522D]/30');

fs.writeFileSync('src/App.tsx', content);
