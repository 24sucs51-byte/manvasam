export const WHATSAPP_CONFIG = {
  groupLink: "https://chat.whatsapp.com/E9GDcJ1Sfu9AcOu2PAtNNK"
};
