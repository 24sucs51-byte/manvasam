export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About",
      events: "Events",
      gallery: "Gallery",
      join: "Join",
      contact: "Contact",
      admin: "Admin",
      photos: "Photos",
      reels: "Reels",
      videos: "Videos",
      testimonials: "Testimonials",
      sponsors: "Sponsors",
      collaborators: "Collaborators",
      terms: "Terms & Conditions",
      privacy: "Privacy Policy"
    },
    hero: {
      title: "மதுரை மண்வாசம்",
      subtitle: "மதுரைக்காரனா மதுரைக்காக மாபெரும் முயற்சி",
      cta: "Register Now"
    },
    about: {
      title: "About Madurai Manvasam",
      content: "Madurai Manvasam is a community-driven initiative dedicated to restoring the cleanliness and heritage of Madurai. We believe in collective action to make our city a better place for future generations."
    },
    impact: {
      title: "Our Impact",
      stat1: "1000+ Volunteers",
      stat2: "50+ Cleanups",
      stat3: "20+ Areas Restored"
    },
    volunteer: {
      title: "Become a Volunteer",
      name: "Name",
      phone: "Phone Number",
      submit: "Join",
      success: "Successfully joined the event!",
      eventLabel: "Select Event",
      register: "Register Now",
      joinEvent: "Join Event",
      joinedSuccess: "You have successfully joined this event",
      selectEvent: "Please select an event",
      age: "Age",
      gender: "Gender",
      area: "Your Area",
      futurePlan: "Future Plan (Optional)",
      problemArea: "Suggested Area (Optional)",
      selectGender: "Select Gender",
      male: "Male",
      female: "Female",
      other: "Other",
      futurePlanPlaceholder: "Any ideas to keep Madurai clean?",
      problemAreaPlaceholder: "Which place needs cleaning?",
      submitting: "Submitting...",
      submitSuccess: "Successfully submitted!",
      submitError: "Something went wrong. Try again!"
    },
    admin: {
      login: "Admin Login",
      username: "Username",
      password: "Password",
      enter: "Login",
      dashboard: "Admin Dashboard",
      logout: "Logout",
      addEvent: "Add Event",
      addTestimonial: "Add Testimonial",
      updateQuotes: "Update Quotes",
      mediaManagement: "Media Management",
      volunteers: "Volunteers",
      media: "Media",
      events: "Events",
      testimonials: "Testimonials",
      addMedia: "Add Media",
      delete: "Delete",
      upload: "Upload",
      mediaType: "Media Type",
      photo: "Photo",
      reel: "Reel",
      video: "Video",
      mediaUrl: "Media URL",
      noVolunteers: "No volunteers registered yet.",
      noMedia: "No media uploaded yet.",
      activeVolunteers: "Active Volunteers",
      completedVolunteers: "Completed Volunteers",
      totalVolunteers: "Total Volunteers",
      totalEvents: "Total Events",
      sponsors: "Sponsors",
      collaborators: "Collaborators",
      addSponsor: "Add Sponsor",
      addCollaborator: "Add Collaborator",
    },
    brand: {
      title: "Designed & Developed By",
      content: "This platform is proudly designed and developed by BrandWE4 to support social impact initiatives."
    },
    privacy: {
      title: "Privacy Policy",
      content: "At Madurai Manvasam, we value your privacy. We collect only necessary information to coordinate our community cleanup events. Your data is used exclusively for project coordination and communication. We strictly maintain that your data will not be sold, traded, or shared with any third parties for marketing purposes. Your information is stored securely, and you have the right to request the removal of your data from our records at any time."
    },
    terms: {
      title: "Terms & Conditions",
      content: "By accessing this platform, you agree to provide accurate information for volunteer registration. Madurai Manvasam is a non-profit community initiative. Users agree not to misuse the platform or its content. All branding and assets belong to Madurai Manvasam and may not be used without prior written consent."
    }
  },
  ta: {
    nav: {
      home: "முகப்பு",
      about: "எங்களைப் பற்றி",
      events: "நிகழ்வுகள்",
      gallery: "கேலரி",
      join: "இணையுங்கள்",
      contact: "தொடர்பு",
      admin: "நிர்வாகம்",
      photos: "புகைப்படங்கள்",
      reels: "ரீல்ஸ்",
      videos: "வீடியோக்கள்",
      testimonials: "சான்றுகள்",
      sponsors: "ஆதரவாளர்கள்",
      collaborators: "ஒத்துழைப்பாளர்கள்",
      terms: "விதிமுறைகள்",
      privacy: "தனியுரிமை"
    },
    hero: {
      title: "மதுரை மண்வாசம்",
      subtitle: "மதுரைக்காரனா மதுரைக்காக மாபெரும் முயற்சி",
      cta: "இப்போதே பதிவு செய்யுங்கள்"
    },
    about: {
      title: "மதுரை மண்வாசம் பற்றி",
      content: "மதுரை மண்வாசம் என்பது மதுரையின் தூய்மை மற்றும் பாரம்பரியத்தை மீட்டெடுப்பதற்காக அர்ப்பணிக்கப்பட்ட ஒரு சமூக முன்முயற்சியாகும். எதிர்கால சந்ததியினருக்கு நமது நகரத்தை சிறந்த இடமாக மாற்ற கூட்டு நடவடிக்கையில் நாங்கள் நம்புகிறோம்."
    },
    impact: {
      title: "எங்கள் தாக்கம்",
      stat1: "1000+ தன்னார்வலர்கள்",
      stat2: "50+ தூய்மைப் பணிகள்",
      stat3: "20+ இடங்கள் மீட்பு"
    },
    volunteer: {
      title: "தன்னார்வலராகுங்கள்",
      name: "பெயர்",
      phone: "தொலைபேசி எண்",
      submit: "இணையுங்கள்",
      success: "நிகழ்வில் வெற்றிகரமாக இணைந்துள்ளீர்கள்!",
      eventLabel: "நிகழ்வைத் தேர்ந்தெடுக்கவும்",
      register: "இப்போதே பதிவு செய்யுங்கள்",
      joinEvent: "நிகழ்வில் சேர்",
      joinedSuccess: "இந்த நிகழ்வில் நீங்கள் வெற்றிகரமாக இணைந்துள்ளீர்கள்",
      selectEvent: "தயவுசெய்து ஒரு நிகழ்வைத் தேர்ந்தெடுக்கவும்",
      age: "வயது",
      gender: "பாலினம்",
      area: "உங்கள் பகுதி",
      futurePlan: "எதிர்கால திட்டம் (விருப்பம்)",
      problemArea: "பரிந்துரைக்கப்படும் பகுதி (விருப்பம்)",
      selectGender: "தேர்ந்தெடு",
      male: "ஆண்",
      female: "பெண்",
      other: "பிற",
      futurePlanPlaceholder: "மதுரையை சுத்தமாக வைத்திருக்க உங்கள் யோசனை?",
      problemAreaPlaceholder: "எந்த இடம் சுத்தம் செய்ய வேண்டும்?",
      submitting: "சமர்ப்பிக்கிறது...",
      submitSuccess: "வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது!",
      submitError: "ஏதோ தவறு நடந்துவிட்டது. மீண்டும் முயற்சிக்கவும்!"
    },
    admin: {
      login: "நிர்வாகி உள்நுழைவு",
      username: "பயனர் பெயர்",
      password: "கடவுச்சொல்",
      enter: "உள்நுழை",
      dashboard: "நிர்வாகி டாஷ்போர்டு",
      logout: "வெளியேறு",
      addEvent: "நிகழ்வைச் சேர்",
      addTestimonial: "சான்றைச் சேர்",
      updateQuotes: "மேற்கோள்களைப் புதுப்பி",
      activeVolunteers: "செயலில் உள்ள தன்னார்வலர்கள்",
      completedVolunteers: "முடித்த தன்னார்வலர்கள்",
      totalVolunteers: "மொத்த தன்னார்வலர்கள்",
      totalEvents: "மொத்த நிகழ்வுகள்",
      sponsors: "ஆதரவாளர்கள்",
      collaborators: "ஒத்துழைப்பாளர்கள்",
      addSponsor: "ஆதரவாளரைச் சேர்",
      addCollaborator: "ஒத்துழைப்பாளரைச் சேர்",
    },
    brand: {
      title: "வடிவமைத்து உருவாக்கியவர்",
      content: "இந்த இணையதளம் BrandWE4 மூலம் சமூக நலத்திற்காக உருவாக்கப்பட்டது."
    },
    privacy: {
      title: "தனியுரிமைக் கொள்கை",
      content: "மதுரை மண்வாசத்தில், உங்கள் தனியுரிமையை நாங்கள் மதிக்கிறோம். எங்கள் சமூக தூய்மைப் பணிகளை ஒருங்கிணைக்க தேவையான தகவல்களை மட்டுமே நாங்கள் சேகரிக்கிறோம். உங்கள் தரவு திட்ட ஒருங்கிணைப்பு மற்றும் தொடர்புகளுக்காக மட்டுமே பயன்படுத்தப்படுகிறது. உங்கள் தரவு சந்தைப்படுத்தல் நோக்கங்களுக்காக எந்த மூன்றாம் தரப்பினருடனும் விற்கப்படாது அல்லது பகிரப்படாது என்பதை நாங்கள் உறுதியாகக் கூறுகிறோம்."
    },
    terms: {
      title: "விதிமுறைகள் மற்றும் நிபந்தனைகள்",
      content: "இந்தத் தளத்தைப் பயன்படுத்துவதன் மூலம், தன்னார்வலர் பதிவிற்கு துல்லியமான தகவலை வழங்க ஒப்புக்கொள்கிறீர்கள். மதுரை மண்வாசம் என்பது ஒரு இலாப நோக்கற்ற சமூக முன்முயற்சியாகும். பயனர்கள் தளத்தையோ அல்லது அதன் உள்ளடக்கத்தையோ தவறாகப் பயன்படுத்தக் கூடாது."
    }
  }
};
