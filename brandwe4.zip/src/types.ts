
export type Language = 'en' | 'ta';

export interface Event {
  id: number;
  title: string;
  date: string; // ISO string for easier comparison
  time: string; // Time of the event
  location: string;
  image: string;
  description: string;
}

export interface Testimonial {
  id: number;
  text: string;
  name: string;
}

export interface MediaItem {
  id: number;
  type: 'photo' | 'reel' | 'video';
  url: string;
  thumbnail: string;
  title: string;
}

export interface Sponsor {
  id: number;
  name: string;
  logo: string;
}

export interface Collaborator {
  id: number;
  name: string;
  logo: string;
}

export interface VolunteerRecord {
  id: string;
  userName: string;
  phone: string;
  age: string;
  gender: string;
  area: string;
  eventId: number;
  eventName: string;
  eventDate: string;
  futurePlan?: string;
  suggestedArea?: string;
  joinedAt: string;
}
