/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import imageCompression from 'browser-image-compression';
import { motion, AnimatePresence, useScroll, useTransform, useMotionValue, animate, useInView } from 'motion/react';
import { 
  Globe, 
  Menu, 
  X, 
  Instagram, 
  Heart, 
  Users, 
  Trash2, 
  Calendar, 
  Image as ImageIcon, 
  Film, 
  Play, 
  ChevronRight, 
  ChevronLeft,
  Quote,
  Lock,
  LogOut,
  Plus,
  CheckCircle2,
  Lightbulb,
  User as UserIcon,
  LogIn,
  UserPlus,
  Share2,
  Clock,
  MapPin,
  ClipboardList,
  UserCheck,
  Award,
  Handshake,
  ChevronDown,
  ArrowRight,
  MessageCircle,
  RefreshCw
} from 'lucide-react';
import { translations } from './translations';
import { Language, Event, Testimonial, MediaItem, VolunteerRecord, Sponsor, Collaborator } from './types';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { WHATSAPP_CONFIG } from './constants';
import { auth, db, storage } from './firebase';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc, 
  setDoc, 
  query, 
  orderBy, 
  getDoc,
  getDocFromServer
} from 'firebase/firestore';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { 
  onAuthStateChanged, 
  signOut, 
  GoogleAuthProvider, 
  signInWithPopup 
} from 'firebase/auth';

// --- Error Handling ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// --- Mock Data ---
const INITIAL_EVENTS: Event[] = [
  { 
    id: 1, 
    title: "Vaigai River Cleanup", 
    date: "2026-03-25", 
    time: "07:00 AM",
    location: "Vaigai Bank", 
    image: "https://picsum.photos/seed/river/600/400",
    description: "Join us for a massive cleanup drive at the banks of Vaigai river. Let's restore its glory."
  },
  { 
    id: 2, 
    title: "Meenakshi Temple Surroundings", 
    date: "2026-04-05", 
    time: "06:30 AM",
    location: "Temple Area", 
    image: "https://picsum.photos/seed/temple/600/400",
    description: "Cleaning the sacred surroundings of our historic temple. Community action for heritage."
  },
  { 
    id: 3, 
    title: "Eco-Awareness Workshop", 
    date: "2026-04-12", 
    time: "10:00 AM",
    location: "Madurai Library", 
    image: "https://picsum.photos/seed/workshop/600/400",
    description: "Educational session on waste management and sustainable living for the youth of Madurai."
  },
];

const INITIAL_TESTIMONIALS: Testimonial[] = [
  { id: 1, text: "BRANDWE4 transformed our raw footage into a cinematic masterpiece. Highly recommended!", name: "Anitha R." },
  { id: 2, text: "உயர்தர வீடியோ எடிட்டிங் மற்றும் சினிமா அனுபவத்திற்கு BRANDWE4 சிறந்த இடம்.", name: "கார்த்திக் எஸ்." },
  { id: 3, text: "The attention to detail in their editing is unparalleled. A true professional team.", name: "Dr. Murugan" },
  { id: 4, text: "BRANDWE4 helped us tell our story in the most impactful way possible.", name: "Priya K." },
  { id: 5, text: "BRANDWE4 உடன் பணிபுரிந்தது ஒரு சிறந்த அனுபவமாக இருந்தது.", name: "செல்வம்" },
];


// Helper to convert Google Drive links
const convertDriveUrl = (url: string): string => {
  if (url.includes('drive.google.com/file/d/')) {
    const fileId = url.split('/d/')[1].split('/')[0];
    return `https://drive.google.com/uc?export=view&id=${fileId}`;
  }
  return url;
};
const INITIAL_MEDIA: MediaItem[] = [
  { id: 1, type: 'photo', url: 'https://picsum.photos/seed/p1/800/600', thumbnail: 'https://picsum.photos/seed/p1/400/300', title: 'Photo 1' },
  { id: 2, type: 'photo', url: 'https://picsum.photos/seed/p2/800/600', thumbnail: 'https://picsum.photos/seed/p2/400/300', title: 'Photo 2' },
  { id: 3, type: 'photo', url: 'https://picsum.photos/seed/p3/800/600', thumbnail: 'https://picsum.photos/seed/p3/400/300', title: 'Photo 3' },
  { id: 4, type: 'photo', url: 'https://picsum.photos/seed/p4/800/600', thumbnail: 'https://picsum.photos/seed/p4/400/300', title: 'Photo 4' },
  { id: 5, type: 'photo', url: 'https://picsum.photos/seed/p5/800/600', thumbnail: 'https://picsum.photos/seed/p5/400/300', title: 'Photo 5' },
  { id: 6, type: 'photo', url: 'https://picsum.photos/seed/p6/800/600', thumbnail: 'https://picsum.photos/seed/p6/400/300', title: 'Photo 6' },
  { id: 7, type: 'photo', url: 'https://picsum.photos/seed/p7/800/600', thumbnail: 'https://picsum.photos/seed/p7/400/300', title: 'Photo 7' },
  { id: 8, type: 'photo', url: 'https://picsum.photos/seed/p8/800/600', thumbnail: 'https://picsum.photos/seed/p8/400/300', title: 'Photo 8' },
  { id: 9, type: 'reel', url: 'https://drive.google.com/uc?export=download&id=1XG0NeF_VS7MUD4qcg0xi4vbhBLUAq2Jv', thumbnail: 'https://picsum.photos/seed/r1/400/711', title: 'Reel 1' },
  { id: 10, type: 'reel', url: 'https://drive.google.com/uc?export=download&id=16fVy5O-zdJwhyhdrla-F8mgntWYqxMTr', thumbnail: 'https://picsum.photos/seed/r2/400/711', title: 'Reel 2' },
  { id: 13, type: 'video', url: 'https://www.w3schools.com/html/mov_bbb.mp4', thumbnail: 'https://picsum.photos/seed/v1/800/450', title: 'Video 1' },
  { id: 14, type: 'video', url: 'https://www.w3schools.com/html/mov_bbb.mp4', thumbnail: 'https://picsum.photos/seed/v2/800/450', title: 'Video 2' },
];

const INITIAL_SPONSORS: Sponsor[] = [
  { id: 1, name: "EcoCorp", logo: "https://picsum.photos/seed/logo1/200/100" },
  { id: 2, name: "GreenTrust", logo: "https://picsum.photos/seed/logo2/200/100" },
  { id: 3, name: "MaduraiTech", logo: "https://picsum.photos/seed/logo3/200/100" },
  { id: 4, name: "EarthCare", logo: "https://picsum.photos/seed/logo4/200/100" },
];

const INITIAL_COLLABORATORS: Collaborator[] = [
  { id: 1, name: 'Green Peace', logo: 'https://picsum.photos/seed/collab0/100/100' },
  { id: 2, name: 'Nature First', logo: 'https://picsum.photos/seed/collab1/100/100' },
  { id: 3, name: 'Eco Warriors', logo: 'https://picsum.photos/seed/collab2/100/100' },
  { id: 4, name: 'Earth Guardians', logo: 'https://picsum.photos/seed/collab3/100/100' },
];

const QUOTES = [
  { en: "The earth does not belong to us: we belong to the earth.", ta: "பூமி நமக்குச் சொந்தமானது அல்ல: நாம் தான் பூமிக்குச் சொந்தமானவர்கள்." },
  { en: "Cleanliness is next to godliness.", ta: "சுத்தமே சுகாதாரம்." },
  { en: "Be the change you wish to see in the world.", ta: "உலகில் நீங்கள் காண விரும்பும் மாற்றமாக நீங்களே இருங்கள்." },
];

// --- Components ---

const Magnetic = ({ children }: { children: React.ReactNode }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    const { clientX, clientY } = e;
    const { left, top, width, height } = ref.current!.getBoundingClientRect();
    const x = clientX - (left + width / 2);
    const y = clientY - (top + height / 2);
    setPosition({ x: x * 0.3, y: y * 0.3 });
  };

  const handleMouseLeave = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", damping: 15, stiffness: 150, mass: 0.1 }}
    >
      {children}
    </motion.div>
  );
};

const LandingIntro = ({ onComplete }: { onComplete: () => void }) => {
  return (
    <motion.div 
      className="fixed inset-0 z-[100] bg-[#f5f5f0] flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 1 }}
      animate={{ opacity: 0 }}
      transition={{ delay: 3, duration: 1 }}
      onAnimationComplete={onComplete}
    >
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
        className="flex flex-col items-center"
      >
        {/* Simple Tree SVG */}
        <motion.svg 
          width="100" 
          height="150" 
          viewBox="0 0 100 150"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2, ease: "easeInOut" }}
        >
          <path d="M50 150 L50 80 M50 80 L20 50 M50 80 L80 50 M50 60 L30 30 M50 60 L70 30" stroke="#065f46" strokeWidth="6" fill="none" />
          <circle cx="20" cy="50" r="15" fill="#059669" />
          <circle cx="80" cy="50" r="15" fill="#059669" />
          <circle cx="30" cy="30" r="15" fill="#059669" />
          <circle cx="70" cy="30" r="15" fill="#059669" />
          <circle cx="50" cy="20" r="15" fill="#059669" />
        </motion.svg>

        <motion.h1 
          className="text-4xl md:text-6xl font-serif italic text-[#A0522D] text-center mt-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          Madurai Manvasam
        </motion.h1>
      </motion.div>
    </motion.div>
  );
};

// --- Components ---
const CountUp = ({ end, duration = 2 }: { end: number; duration?: number }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const increment = end / (duration * 60);
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 1000 / 60);
    return () => clearInterval(timer);
  }, [end, duration]);
  return <>{count}</>;
};

const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwwp0Lu0Q2_MFpMlKUXyq5rKPzYGlITULhl_DII2zhP_zSSvMrTKRvviPUvP4pJ5zb_FQ/exec";

// --- Helper Components ---
function Counter({ value, showPlus = false }: { value: number, showPlus?: boolean }) {
  const count = useMotionValue(0);
  const displayValue = useTransform(count, (latest) => Math.round(latest) + (showPlus ? '+' : ''));
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      const controls = animate(count, value, { duration: 2, ease: "easeOut" });
      return () => controls.stop();
    }
  }, [value, isInView]);
  
  return <motion.span ref={ref}>{displayValue}</motion.span>;
}

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [showIntro, setShowIntro] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  
  // Admin State
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  
  // Join Form State
  const [joinForm, setJoinForm] = useState({ 
    name: '', 
    phone: '', 
    age: '', 
    gender: '', 
    area: '', 
    eventId: '',
    futurePlan: '',
    suggestedArea: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [formMessage, setFormMessage] = useState<{ text: string; type: 'success' | 'error' | null }>({ text: '', type: null });

  const showMessage = (msg: string, type: 'success' | 'error') => {
    setFormMessage({ text: msg, type });
    setTimeout(() => {
      setFormMessage({ text: '', type: null });
    }, 3000);
  };
  
  // Volunteer & Event State
  const { scrollYProgress } = useScroll();
  const heroVisualY = useTransform(scrollYProgress, [0, 1], [0, 300]);

  const [volunteerRecords, setVolunteerRecords] = useState<VolunteerRecord[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<MediaItem | null>(null);
  const modalVideoRef = useRef<HTMLVideoElement>(null);
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  
  const [events, setEvents] = useState<Event[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [sponsors, setSponsors] = useState<Sponsor[]>([]);
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'volunteers' | 'media' | 'events' | 'testimonials' | 'records' | 'sponsors' | 'collaborators'>('overview');
  const [activeMediaTab, setActiveMediaTab] = useState<'photo' | 'reel' | 'video'>('photo');
  
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [newMediaTitle, setNewMediaTitle] = useState('');
  const [newMediaThumbnail, setNewMediaThumbnail] = useState('');
  const [newMediaType, setNewMediaType] = useState<'photo' | 'reel' | 'video'>('photo');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const [newEvent, setNewEvent] = useState({ title: '', date: '', time: '', location: '', description: '', image: '' });
  const [adminEventFilter, setAdminEventFilter] = useState<'all' | 'today' | 'upcoming' | 'completed'>('all');
  const [adminVolunteerFilter, setAdminVolunteerFilter] = useState<'all' | 'low' | 'medium' | 'high'>('all');
  const [newTestimonial, setNewTestimonial] = useState({ text: '', name: '' });
  const [newSponsor, setNewSponsor] = useState({ name: '', logo: '' });
  const [newCollaborator, setNewCollaborator] = useState({ name: '', logo: '' });
  const [selectedAdminEventId, setSelectedAdminEventId] = useState<number | null>(null);
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark' | 'emerald'>('light');
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isNavVisible, setIsNavVisible] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [user, setUser] = useState<any>(null);

  const t = translations[lang];

  // Test Connection
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        // Check if admin
        const adminEmail = "24sucs51@tcarts.in";
        if (user.email === adminEmail && user.emailVerified) {
          setIsAdminLoggedIn(true);
        } else {
          // Check users collection for admin role
          try {
            const userDoc = await getDoc(doc(db, 'users', user.uid));
            if (userDoc.exists() && userDoc.data().role === 'admin') {
              setIsAdminLoggedIn(true);
            } else {
              setIsAdminLoggedIn(false);
            }
          } catch (e) {
            setIsAdminLoggedIn(false);
          }
        }
      } else {
        setIsAdminLoggedIn(false);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Firestore Listeners
  useEffect(() => {
    const unsubEvents = onSnapshot(collection(db, 'events'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.data().id || doc.id }) as Event);
      setEvents(data.length > 0 ? data : INITIAL_EVENTS);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'events'));

    const unsubMedia = onSnapshot(collection(db, 'media'), (snapshot) => {
      const firestoreData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.data().id || doc.id }) as MediaItem);
      
      const photos = firestoreData.filter(m => m.type === 'photo');
      const reels = firestoreData.filter(m => m.type === 'reel');
      const videos = firestoreData.filter(m => m.type === 'video');

      // If Firestore has data for a type, use it. Otherwise use INITIAL_MEDIA.
      const mergedMedia = [
        ...(photos.length > 0 ? photos : INITIAL_MEDIA.filter(m => m.type === 'photo')),
        ...(reels.length > 0 ? reels : INITIAL_MEDIA.filter(m => m.type === 'reel')),
        ...(videos.length > 0 ? videos : INITIAL_MEDIA.filter(m => m.type === 'video')),
      ];
      
      setMedia(mergedMedia);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'media'));

    const unsubTestimonials = onSnapshot(collection(db, 'testimonials'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.data().id || doc.id }) as Testimonial);
      setTestimonials(data.length > 0 ? data : INITIAL_TESTIMONIALS);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'testimonials'));

    const unsubSponsors = onSnapshot(collection(db, 'sponsors'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.data().id || doc.id }) as Sponsor);
      setSponsors(data.length > 0 ? data : INITIAL_SPONSORS);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'sponsors'));

    const unsubCollaborators = onSnapshot(collection(db, 'collaborators'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.data().id || doc.id }) as Collaborator);
      setCollaborators(data.length > 0 ? data : INITIAL_COLLABORATORS);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'collaborators'));

    return () => {
      unsubEvents();
      unsubMedia();
      unsubTestimonials();
      unsubSponsors();
      unsubCollaborators();
    };
  }, []);

  // Admin-only listeners
  useEffect(() => {
    if (!isAdminLoggedIn) {
      setVolunteerRecords([]);
      return;
    }
    const unsubVolunteers = onSnapshot(collection(db, 'volunteerRecords'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }) as VolunteerRecord);
      setVolunteerRecords(data);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'volunteerRecords'));

    return () => unsubVolunteers();
  }, [isAdminLoggedIn]);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Hide/Show navbar logic
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsNavVisible(false);
      } else {
        setIsNavVisible(true);
      }
      
      // Close mobile menu on scroll
      if (isNavOpen) {
        setIsNavOpen(false);
      }

      setLastScrollY(currentScrollY);
      setIsScrolled(currentScrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY, isNavOpen]);

  useEffect(() => {
    if (showJoinModal) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [showJoinModal]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuoteIndex((prev) => (prev + 1) % QUOTES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const toggleLang = () => {
    setLang(lang === 'en' ? 'ta' : 'en');
  };

  const handleAddEvent = async () => {
    if (!newEvent.title || !newEvent.date || !newEvent.time) return;
    const item: Event = {
      id: Date.now(),
      title: newEvent.title,
      date: newEvent.date,
      time: newEvent.time,
      location: newEvent.location || '',
      description: newEvent.description || '',
      image: newEvent.image || `https://picsum.photos/seed/${Date.now()}/600/400`
    };
    try {
      await setDoc(doc(db, 'events', item.id.toString()), item);
      setNewEvent({ title: '', date: '', time: '', location: '', description: '', image: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'events');
    }
  };

  const handleDeleteEvent = async (id: number) => {
    try {
      await deleteDoc(doc(db, 'events', id.toString()));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'events');
    }
  };

  const handleAddTestimonial = async () => {
    if (!newTestimonial.text || !newTestimonial.name) return;
    const item: Testimonial = {
      id: Date.now(),
      ...newTestimonial
    };
    try {
      await setDoc(doc(db, 'testimonials', item.id.toString()), item);
      setNewTestimonial({ text: '', name: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'testimonials');
    }
  };

  const handleDeleteTestimonial = async (id: number) => {
    try {
      await deleteDoc(doc(db, 'testimonials', id.toString()));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'testimonials');
    }
  };

  const handleAddSponsor = async () => {
    if (!newSponsor.name || !newSponsor.logo) return;
    const sponsor: Sponsor = {
      id: Date.now(),
      ...newSponsor
    };
    try {
      await setDoc(doc(db, 'sponsors', sponsor.id.toString()), sponsor);
      setNewSponsor({ name: '', logo: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'sponsors');
    }
  };

  const handleDeleteSponsor = async (id: number) => {
    try {
      await deleteDoc(doc(db, 'sponsors', id.toString()));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'sponsors');
    }
  };

  const handleAddCollaborator = async () => {
    if (!newCollaborator.name || !newCollaborator.logo) return;
    const collaborator: Collaborator = {
      id: Date.now(),
      ...newCollaborator
    };
    try {
      await setDoc(doc(db, 'collaborators', collaborator.id.toString()), collaborator);
      setNewCollaborator({ name: '', logo: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'collaborators');
    }
  };

  const handleDeleteCollaborator = async (id: number) => {
    try {
      await deleteDoc(doc(db, 'collaborators', id.toString()));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'collaborators');
    }
  };

  const handleAddMedia = async () => {
    if (!newMediaUrl) return;
    const newItem: MediaItem = {
      id: Date.now(),
      type: newMediaType,
      url: convertDriveUrl(newMediaUrl),
      title: newMediaTitle || 'Untitled',
      thumbnail: newMediaThumbnail || (newMediaType === 'photo' ? newMediaUrl : `https://picsum.photos/seed/${Date.now()}/${newMediaType === 'reel' ? '400/711' : '800/450'}`)
    };
    try {
      await setDoc(doc(db, 'media', newItem.id.toString()), newItem);
      setNewMediaUrl('');
      setNewMediaTitle('');
      setNewMediaThumbnail('');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'media');
    }
  };

  const handleDeleteMedia = async (id: number) => {
    try {
      await deleteDoc(doc(db, 'media', id.toString()));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'media');
    }
  };

  const handleJoinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { name, phone, age, gender, area, eventId, futurePlan, suggestedArea } = joinForm;
    const event = events.find(e => e.id === Number(eventId));

    if (!name.trim() || !phone.trim() || !eventId) {
      showMessage(lang === 'en' ? "Please fill required fields" : "அனைத்து கட்டாய புலங்களையும் நிரப்பவும்", "error");
      return;
    }

    if (!event) return;

    setIsSubmitting(true);

    try {
      // 1. Send data to Google Sheets
      await fetch(SCRIPT_URL, {
        method: "POST",
        mode: "cors",
        headers: {
          "Content-Type": "text/plain;charset=utf-8",
        },
        body: JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          age: age.trim(),
          gender,
          area: area.trim(),
          eventId: event.id,
          eventName: event.title,
          eventDate: event.date,
          futurePlan: futurePlan?.trim() || '',
          suggestedArea: suggestedArea?.trim() || '',
          joinedAt: new Date().toISOString()
        })
      });

      // 2. Save to Firestore
      const newRecord: VolunteerRecord = {
        id: Date.now().toString(),
        userName: name.trim(),
        phone: phone.trim(),
        age: age.trim(),
        gender,
        area: area.trim(),
        eventId: event.id,
        eventName: event.title,
        eventDate: event.date,
        futurePlan: futurePlan?.trim() || '',
        suggestedArea: suggestedArea?.trim() || '',
        joinedAt: new Date().toISOString()
      };
      
      await setDoc(doc(db, 'volunteerRecords', newRecord.id), newRecord);

      showMessage(lang === 'en' ? "Successfully joined! See you there." : "வெற்றிகரமாக இணைந்தீர்கள்! அங்கு சந்திப்போம்.", "success");
      setShowJoinModal(false);
      setJoinForm({ name: '', phone: '', age: '', gender: 'male', area: '', eventId: '', futurePlan: '', suggestedArea: '' });
    } catch (error) {
      console.error("Error joining event:", error);
      showMessage(lang === 'en' ? "Something went wrong. Please try again." : "ஏதோ தவறு நடந்துவிட்டது. மீண்டும் முயற்சிக்கவும்.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleJoinEvent = (event: Event) => {
    setJoinForm({ ...joinForm, eventId: event.id.toString() });
    setShowJoinModal(true);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      const adminEmail = "24sucs51@tcarts.in";
      
      if (user.email === adminEmail && user.emailVerified) {
        setIsAdminLoggedIn(true);
        setShowAdminDashboard(true);
        setShowAdminLogin(false);
        showMessage(lang === 'en' ? "Welcome Admin!" : "வரவேற்கிறோம் அட்மின்!", "success");
      } else {
        // Check users collection
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists() && userDoc.data().role === 'admin') {
          setIsAdminLoggedIn(true);
          setShowAdminDashboard(true);
          setShowAdminLogin(false);
          showMessage(lang === 'en' ? "Welcome Admin!" : "வரவேற்கிறோம் அட்மின்!", "success");
        } else {
          await signOut(auth);
          showMessage(lang === 'en' ? "Access Denied: Not an Admin" : "அனுமதி மறுக்கப்பட்டது: நீங்கள் அட்மின் இல்லை", "error");
        }
      }
    } catch (error) {
      console.error("Login error:", error);
      showMessage(lang === 'en' ? "Login failed" : "உள்நுழைவு தோல்வியடைந்தது", "error");
    }
  };

  const handleAdminLogout = async () => {
    try {
      await signOut(auth);
      setIsAdminLoggedIn(false);
      setShowAdminDashboard(false);
      showMessage(lang === 'en' ? "Logged out successfully" : "வெற்றிகரமாக வெளியேறினீர்கள்", "success");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const fetchVolunteerData = async () => {
    setIsFetching(true);
    try {
      const response = await fetch(SCRIPT_URL);
      const data = await response.json();
      
      // First row is header -> skip it
      const rows = data.slice(1);
      
      const processedRecords: VolunteerRecord[] = rows.map((row: any[], index: number) => {
        const [name, phone, age, gender, area, event, futurePlan, problemArea] = row;
        
        // Try to find the event to get more details if possible
        const matchedEvent = events.find(e => e.title === event);
        
        return {
          id: `gs-${index}`,
          userName: name || '',
          phone: phone || '',
          age: age || '',
          gender: gender || '',
          area: area || '',
          eventId: matchedEvent?.id || 0,
          eventName: event || '',
          eventDate: matchedEvent?.date || '',
          futurePlan: futurePlan || '',
          suggestedArea: problemArea || '',
          joinedAt: new Date().toISOString()
        };
      });
      
      setVolunteerRecords(processedRecords);
      localStorage.setItem('volunteerRecords', JSON.stringify(processedRecords));
    } catch (error) {
      console.error("Error fetching volunteer data:", error);
    } finally {
      setIsFetching(false);
    }
  };

  useEffect(() => {
    if (isAdminLoggedIn) {
      fetchVolunteerData();
    }
  }, [isAdminLoggedIn, events]);

  const handleDeleteVolunteer = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'volunteerRecords', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'volunteerRecords');
    }
  };

  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(error => {
        console.log("Video autoplay failed:", error);
      });
    }
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  if (showIntro) {
    return <LandingIntro onComplete={() => setShowIntro(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#fcfcf9] text-[#A0522D] font-sans selection:bg-[#A0522D]/20 selection:text-[#A0522D]">
      {/* --- Scroll Progress Bar --- */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-emerald-600 z-[200] origin-left"
        style={{ scaleX: scrollYProgress }}
      />

      {/* --- Creative Navigation Bar --- */}
      <motion.nav 
        initial={{ y: 0 }}
        animate={{ y: isNavVisible ? 0 : -100 }}
        transition={{ duration: 0.3 }}
        className="fixed top-2 left-2 right-2 md:top-4 md:left-6 md:right-6 z-[100] p-2 px-4 md:p-3 md:px-6 flex justify-between items-center pointer-events-none bg-white/70 backdrop-blur-md rounded-full border border-[#A0522D]/20 shadow-lg"
      >
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="pointer-events-auto"
        >
          <div className="text-lg md:text-2xl font-black text-[#A0522D] flex items-center gap-2 group">
            <img 
              src="https://lh3.googleusercontent.com/d/19zXOX6bI5w4OIGRZIDa7lUB83T3j2ybn" 
              alt="Logo" 
              className="w-8 h-8 md:w-10 md:h-10 object-contain" 
              referrerPolicy="no-referrer" 
            />
            <span className={`tracking-tighter uppercase ${lang === 'en' ? 'font-display' : 'font-tamil'}`}>
              {lang === 'en' ? 'Madurai Manvasam' : 'மதுரை மண்வாசம்'}
            </span>
          </div>
        </motion.div>

        <div className="flex items-center gap-2 md:gap-6 pointer-events-auto">
          <button 
            onClick={() => setLang(lang === 'en' ? 'ta' : 'en')}
            className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-[#A0522D]/20 flex items-center justify-center text-xs font-bold text-[#A0522D]/80 hover:bg-[#A0522D]/5 transition-colors bg-white/50 backdrop-blur-md"
          >
            {lang.toUpperCase()}
          </button>

          <button 
            onClick={() => isAdminLoggedIn ? setShowAdminDashboard(true) : setShowAdminLogin(true)}
            className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-[#A0522D]/20 flex items-center justify-center text-[#A0522D]/80 hover:bg-[#A0522D]/5 transition-colors bg-white/50 backdrop-blur-md"
            title={isAdminLoggedIn ? "Admin Dashboard" : "Admin Login"}
          >
            {isAdminLoggedIn ? <Globe size={18} className="text-emerald-600" /> : <Lock size={18} />}
          </button>

          <button 
            onClick={() => {
              if (navigator.share) {
                navigator.share({
                  title: 'GreenEarth',
                  text: 'Check out GreenEarth!',
                  url: window.location.href,
                }).catch(console.error);
              }
            }}
            className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-[#A0522D]/20 flex items-center justify-center text-[#A0522D]/80 hover:bg-[#A0522D]/5 transition-colors bg-white/50 backdrop-blur-md"
          >
            <Share2 size={18} />
          </button>
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsNavOpen(!isNavOpen)}
            className="w-10 h-10 md:w-12 md:h-12 bg-[#A0522D] text-white rounded-full flex items-center justify-center shadow-lg relative overflow-hidden group"
          >
            <AnimatePresence mode="wait">
              {isNavOpen ? <X key="x" size={20} /> : <Menu key="menu" size={20} />}
            </AnimatePresence>
          </motion.button>
        </div>
      </motion.nav>

      {/* --- Dropdown Navigation Menu --- */}
      <AnimatePresence>
        {isNavOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed top-16 right-2 md:top-20 md:right-6 z-[90] bg-white/90 backdrop-blur-md rounded-3xl p-6 shadow-2xl border border-[#A0522D]/20 w-64"
          >
            <div className="flex flex-col space-y-4">
              {['home', 'about', 'events', 'gallery', 'join', 'contact'].map((item) => (
                <a
                  key={item}
                  href={`#${item}`}
                  onClick={(e) => {
                    e.preventDefault();
                    if (item === 'join') {
                      setShowJoinModal(true);
                    } else if (item === 'gallery') {
                      scrollToSection('photos');
                    } else {
                      scrollToSection(item);
                    }
                    setIsNavOpen(false);
                  }}
                  className="text-lg font-medium text-[#A0522D] hover:text-emerald-600 transition-colors"
                >
                  {(t.nav as any)[item]}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        <motion.main
          key={lang}
          initial={{ opacity: 0 }}
          animate={{ 
            opacity: 1,
            backgroundColor: currentTheme === 'dark' ? '#111827' : currentTheme === 'emerald' ? '#064e3b' : '#fcfcf9',
            color: currentTheme === 'light' ? '#064e3b' : '#f0fdf4'
          }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="relative transition-colors duration-1000"
        >
          {/* Floating Background Icons */}
          <div className="fixed inset-0 pointer-events-none overflow-hidden z-0 opacity-[0.03]">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-[#A0522D]"
                initial={{ 
                  x: Math.random() * 100 + "%", 
                  y: Math.random() * 100 + "%",
                  rotate: Math.random() * 360
                }}
                animate={{ 
                  y: [null, "-20%", "20%", "0%"],
                  rotate: [null, 360],
                  scale: [1, 1.2, 0.8, 1]
                }}
                transition={{ 
                  duration: 20 + Math.random() * 20, 
                  repeat: Infinity, 
                  ease: "linear" 
                }}
              >
                {i % 3 === 0 ? <Trash2 size={120} /> : i % 3 === 1 ? <Heart size={120} /> : <Globe size={120} />}
              </motion.div>
            ))}
          </div>

          {/* --- Full-Screen Video Hero --- */}
          <section id="home" className="relative h-[100dvh] w-full overflow-hidden flex items-center justify-center">
            {/* Background Video */}
            <video
              ref={videoRef}
              autoPlay
              muted
              loop
              playsInline
              preload="auto"
              poster="https://picsum.photos/seed/madurai/480/270?blur=4"
              className="absolute inset-0 w-full h-full object-cover z-0"
              style={{ objectPosition: 'center' }}
            >
              <source src="https://drive.google.com/uc?export=download&id=14zNFrFIbjL1Rxm5uzK0zhU_JD2WOXVUJ" type="video/mp4" />
            </video>

            {/* Dark Overlay for Readability */}
            <div className="absolute inset-0 bg-black/30 z-[1]" />

            {/* Content Overlay */}
            <div className="relative z-10 text-center px-6">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, ease: "easeOut" }}
              >
                <h1 className="text-6xl md:text-9xl font-sans font-black uppercase text-[#FFD700] leading-tight mb-6 tracking-tighter drop-shadow-[0_10px_10px_rgba(0,0,0,0.5)]">
                  {t.hero.title.split('').map((char, i) => (
                    <motion.span
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 + 0.5 }}
                    >
                      {char}
                    </motion.span>
                  ))}
                </h1>
                <motion.span 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.5, delay: 1 }}
                  className="text-amber-200 font-bold mb-12 block drop-shadow-lg text-lg md:text-3xl italic tracking-normal"
                >
                  {t.hero.subtitle}
                </motion.span>
                
                <div className="flex flex-wrap justify-center gap-6">
                  <Magnetic>
                    <motion.button 
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setShowJoinModal(true)}
                      className="px-12 py-6 bg-[#FFD700] text-black rounded-full font-bold text-xl hover:bg-white transition-all shadow-[0_20px_50px_rgba(255,215,0,0.3)]"
                    >
                      {t.hero.cta}
                    </motion.button>
                  </Magnetic>
                </div>
              </motion.div>
            </div>
          </section>



      {/* --- Join Modal --- */}
      <AnimatePresence>
        {showJoinModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-[2rem] p-6 md:p-8 max-w-md w-full shadow-2xl relative max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6 border-b border-[#A0522D]/10 pb-4">
                <h2 className="text-2xl font-serif italic text-[#A0522D]">{t.volunteer.title}</h2>
                <button 
                  onClick={() => setShowJoinModal(false)}
                  className="w-10 h-10 bg-[#A0522D]/5 text-[#A0522D] hover:bg-[#A0522D] hover:text-white rounded-full flex items-center justify-center transition-all shadow-sm"
                  aria-label="Cancel"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Form Header */}
              <div className="text-center mb-6">
                <p className="text-sm text-[#A0522D]/70">
                  {lang === 'en' 
                    ? "Join the great effort for Madurai. Register now and be part of the change."
                    : "மதுரைக்கான மாபெரும் முயற்சியில் இணையுங்கள். இப்போதே பதிவு செய்து மாற்றத்தின் ஒரு அங்கமாக இருங்கள்."}
                </p>
              </div>

              <form id="volunteerForm" onSubmit={handleJoinSubmit} className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                      {t.volunteer.name} <span className="text-red-500">*</span>
                    </label>
                    <input 
                      id="name"
                      type="text" 
                      required
                      value={joinForm.name}
                      onChange={(e) => setJoinForm({ ...joinForm, name: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 text-sm"
                      placeholder={t.volunteer.name}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                      {t.volunteer.phone} <span className="text-red-500">*</span>
                    </label>
                    <input 
                      id="phone"
                      type="tel" 
                      required
                      value={joinForm.phone}
                      onChange={(e) => setJoinForm({ ...joinForm, phone: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 text-sm"
                      placeholder={t.volunteer.phone}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                      {t.volunteer.age} <span className="text-red-500">*</span>
                    </label>
                    <input 
                      id="age"
                      type="number" 
                      required
                      value={joinForm.age}
                      onChange={(e) => setJoinForm({ ...joinForm, age: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 text-sm"
                      placeholder={t.volunteer.age}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                      {t.volunteer.gender} <span className="text-red-500">*</span>
                    </label>
                    <select 
                      id="gender"
                      required
                      value={joinForm.gender}
                      onChange={(e) => setJoinForm({ ...joinForm, gender: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 appearance-none cursor-pointer text-sm"
                    >
                      <option value="">{t.volunteer.selectGender}</option>
                      <option value="Male">{t.volunteer.male}</option>
                      <option value="Female">{t.volunteer.female}</option>
                      <option value="Other">{t.volunteer.other}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                    {t.volunteer.area} <span className="text-red-500">*</span>
                  </label>
                  <input 
                    id="area"
                    type="text" 
                    required
                    value={joinForm.area}
                    onChange={(e) => setJoinForm({ ...joinForm, area: e.target.value })}
                    className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 text-sm"
                    placeholder={t.volunteer.area}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                    {t.volunteer.eventLabel} <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <select 
                      id="event"
                      required
                      value={joinForm.eventId}
                      onChange={(e) => setJoinForm({ ...joinForm, eventId: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 appearance-none cursor-pointer text-sm"
                    >
                      <option value="">{t.volunteer.selectEvent}</option>
                      {events.map(event => (
                        <option key={event.id} value={event.id}>
                          {event.title} — {event.date}
                        </option>
                      ))}
                    </select>
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-amber-600">
                      <ChevronDown size={16} />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                      {t.volunteer.futurePlan}
                    </label>
                    <textarea 
                      id="futurePlan"
                      value={joinForm.futurePlan}
                      onChange={(e) => setJoinForm({ ...joinForm, futurePlan: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 h-20 text-sm"
                      placeholder={t.volunteer.futurePlanPlaceholder}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-[#A0522D]/80 mb-1 uppercase tracking-wider">
                      {t.volunteer.problemArea}
                    </label>
                    <textarea 
                      id="problemArea"
                      value={joinForm.suggestedArea}
                      onChange={(e) => setJoinForm({ ...joinForm, suggestedArea: e.target.value })}
                      className="w-full px-4 py-3 bg-[#A0522D]/5 border border-[#A0522D]/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 h-20 text-sm"
                      placeholder={t.volunteer.problemAreaPlaceholder}
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-[#A0522D] text-white rounded-xl font-bold text-lg hover:bg-black transition-all shadow-lg shadow-[#A0522D]/20 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <RefreshCw className="animate-spin" size={20} />
                    ) : (
                      <CheckCircle2 size={20} />
                    )}
                    {isSubmitting ? t.volunteer.submitting : t.volunteer.submit}
                  </motion.button>
                </div>
                
                {formMessage.type && (
                  <div 
                    id="formMessage" 
                    className={`mt-4 p-3 rounded-xl text-center font-bold text-sm ${

                      formMessage.type === 'success' ? 'bg-[#A0522D]/5 text-amber-600' : 'bg-red-50 text-red-600'
                    }`}
                  >
                    {formMessage.text}
                  </div>
                )}
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Volunteer CTA Section --- */}
      <section className="py-24 px-6 bg-[#A0522D]/5 relative overflow-hidden">
        {/* Background Patterns */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-[#A0522D] rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#A0522D]/50 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="bg-white/50 backdrop-blur-xl border border-[#A0522D]/20 rounded-[4rem] p-12 md:p-20 flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="text-center md:text-left max-w-2xl">
              <h2 className="text-4xl md:text-6xl font-serif italic text-[#A0522D] mb-6">
                {t.volunteer.title}
              </h2>
              <p className="text-[#A0522D]/80 text-xl md:text-2xl font-light leading-relaxed">
                {lang === 'en' 
                  ? "Join hundreds of satisfied clients who have transformed their vision into reality. Your story matters."
                  : "உங்கள் கனவை நனவாக்கிய நூற்றுக்கணக்கான திருப்தியான வாடிக்கையாளர்களுடன் இணையுங்கள். உங்கள் கதை முக்கியமானது."}
              </p>
            </div>
            
            <Magnetic>
              <motion.button
                whileHover={{ scale: 1.05, rotate: [0, -2, 2, 0] }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowJoinModal(true)}
                className="px-12 py-6 bg-[#A0522D] text-white rounded-full font-black text-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] hover:bg-[#A0522D] transition-all flex items-center gap-4 group"
              >
                {t.volunteer.register}
                <ArrowRight className="group-hover:translate-x-2 transition-transform" />
              </motion.button>
            </Magnetic>
          </div>
        </div>
      </section>

      {/* --- Sponsors Section --- */}
      <section 
        className="py-24 px-6 overflow-hidden relative bg-[#A0522D]/5"
      >
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-serif italic mb-16 text-center text-[#A0522D]">
            {t.nav.sponsors}
          </h2>
          <div className="relative w-full overflow-hidden">
            <motion.div
              className="flex items-center gap-12 md:gap-24 w-max"
              animate={{ x: ["0%", "-50%"] }}
              transition={{ repeat: Infinity, duration: 20, ease: 'linear' }}
            >
              {[...sponsors, ...sponsors].map((sponsor, i) => (
                <motion.div
                  key={`${sponsor.id}-${i}`}
                  whileHover={{ scale: 1.1 }}
                  className="w-32 md:w-48 transition-all cursor-pointer flex-shrink-0"
                >
                  <img 
                    src={sponsor.logo} 
                    alt={sponsor.name} 
                    className="w-full h-auto"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* --- About Section --- */}
      <section id="about" className="py-24 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl bg-white p-4 flex items-center justify-center">
              <img src="https://lh3.googleusercontent.com/d/1zhS9BCZg1GLUFg-9b5uLo1nqii807QEN" alt="Madurai Manvasam" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-serif italic text-amber-600 mb-8">{t.about.title}</h2>
            <p className="text-lg text-[#A0522D]/80 leading-relaxed mb-8">
              {t.about.content}
            </p>
            <div className="grid grid-cols-2 gap-6">
              {[
                { icon: Trash2, title: lang === 'en' ? "Cleanup Drives" : "தூய்மைப் பணிகள்", desc: lang === 'en' ? "Restoring Madurai" : "மதுரையை மீட்டெடுத்தல்" },
                { icon: Heart, title: lang === 'en' ? "Community Love" : "சமூக அன்பு", desc: lang === 'en' ? "For our city" : "நமது நகரத்திற்காக" }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2, duration: 0.5 }}
                  whileHover={{ y: -10, boxShadow: "0 20px 40px rgba(0,0,0,0.05)" }}
                  className="p-6 bg-white rounded-2xl border border-[#A0522D]/10 shadow-sm transition-all"
                >
                  <item.icon className="text-amber-600 mb-4" size={32} />
                  <h4 className="font-bold text-xl mb-1">{item.title}</h4>
                  <p className="text-sm text-amber-600">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* --- Madurai Manvasam Section (Impact Highlight) --- */}
      <section 
        className="relative w-full py-32 px-6 overflow-hidden bg-[#0a0a0a]"
      >
        {/* Royal/Premium Background with subtle animated gradients */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_#111827_0%,_#000000_100%)]" />
          <motion.div 
            animate={{ 
              backgroundPosition: ['0% 0%', '100% 100%'],
              opacity: [0.3, 0.5, 0.3]
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30"
          />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-emerald-900/30 blur-[120px] rounded-full pointer-events-none" />
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-amber-900/20 blur-[100px] rounded-full pointer-events-none" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="relative rounded-[2.5rem] p-[1px] overflow-hidden"
          >
            {/* Animated Border Gradient */}
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/60 via-transparent to-amber-500/40 opacity-50 transition-opacity duration-700" />
            
            <div className="relative bg-[#0f1115]/90 backdrop-blur-3xl rounded-[2.5rem] p-12 md:p-24 text-center overflow-hidden">
              {/* Inner Glow */}
              <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent opacity-20" />
              
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, delay: 0.2, ease: "easeOut" }}
              >
                <div className="flex items-center justify-center gap-4 mb-8">
                  <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-amber-500/50" />
                  <h3 className="text-amber-500/80 text-xs md:text-sm font-serif italic tracking-[0.5em] uppercase">
                    {lang === 'en' ? 'The BRANDWE4 Legacy' : 'BRANDWE4 பாரம்பரியம்'}
                  </h3>
                  <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-amber-500/50" />
                </div>
                
                <h2 className="text-5xl md:text-7xl lg:text-8xl font-serif font-light text-white mb-8 tracking-[0.15em] drop-shadow-2xl uppercase">
                  BRANDWE4
                </h2>
                
                <p className="text-gray-300 max-w-3xl mx-auto text-lg md:text-2xl font-serif italic leading-relaxed mb-12 opacity-90">
                  {lang === 'en' 
                    ? "Crafting timeless legacies through unwavering loyalty and classic excellence. BRANDWE4 stands as a testament to enduring quality and visionary leadership." 
                    : "உறுதியான விசுவாசம் மற்றும் உன்னதமான சிறப்பின் மூலம் காலத்தால் அழியாத மரபுகளை உருவாக்குதல். BRANDWE4 நிலையான தரம் மற்றும் தொலைநோக்கு தலைமைக்கு ஒரு சான்றாக நிற்கிறது."}
                </p>

                <motion.div 
                  onClick={() => scrollToSection('impact')}
                  className="inline-flex items-center gap-3 text-amber-500 font-medium text-sm tracking-[0.3em] uppercase cursor-pointer hover:text-amber-400 transition-colors duration-500"
                >
                  <span className="relative overflow-hidden pb-1">
                    {lang === 'en' ? 'Explore for more' : 'மேலும் அறிய'}
                    <span className="absolute bottom-0 left-0 w-full h-[1px] bg-amber-400 origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500 ease-out" />
                  </span>
                  <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform duration-500 ease-out" />
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* --- Impact Section --- */}
      <section id="impact" className="py-24 bg-[#f5f5f0]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif italic text-amber-600 mb-4">{t.impact.title}</h2>
            <div className="w-24 h-1 bg-emerald-600 mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { label: lang === 'en' ? 'Volunteers' : 'தன்னார்வலர்கள்', value: 1000, icon: Users, showPlus: true },
              { label: lang === 'en' ? 'Cleanups' : 'தூய்மைப் பணிகள்', value: 50, icon: Trash2, showPlus: true },
              { label: lang === 'en' ? 'Areas Restored' : 'இடங்கள் மீட்பு', value: 20, icon: MapPin, showPlus: true }
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 0.8 }}
                whileHover={{ 
                  scale: 1.05, 
                  rotateY: i % 2 === 0 ? 5 : -5,
                  rotateX: 5,
                  boxShadow: "0 30px 60px rgba(5, 150, 105, 0.15)" 
                }}
                className="bg-white p-10 rounded-3xl text-center shadow-xl transition-all border border-[#A0522D]/10 perspective-1000"
              >
                <div className="w-16 h-16 bg-[#A0522D]/10 rounded-2xl flex items-center justify-center text-amber-600 mx-auto mb-6">
                  <stat.icon size={32} />
                </div>
                <h3 className="text-4xl md:text-5xl font-serif italic text-amber-600 mb-2">
                  <Counter value={stat.value} showPlus={stat.showPlus} />
                </h3>
                <p className="text-[#A0522D] font-medium uppercase tracking-widest text-sm">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Events Section --- */}
      <section id="events" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-4">
            <div>
              <h2 className="text-4xl md:text-5xl font-serif italic text-amber-600 mb-4">{t.nav.events}</h2>
              <p className="text-[#A0522D]/70">Join our upcoming cleanup drives and workshops.</p>
            </div>
            <button className="text-amber-600 font-bold flex items-center gap-2 hover:gap-4 transition-all">
              View All Events <ChevronRight size={20} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {events.map((event, i) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group relative bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all"
              >
                <div className="h-64 overflow-hidden relative">
                  <img src={event.image} alt={event.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
                  {new Date(event.date) < new Date() && (
                    <div className="absolute top-4 right-4 px-4 py-1 bg-black/60 backdrop-blur-md text-white rounded-full text-[10px] font-bold uppercase tracking-widest border border-white/20">
                      Completed
                    </div>
                  )}
                </div>
                <div className="p-8">
                  <div className="flex items-center gap-4 text-amber-600 text-sm font-bold uppercase tracking-tighter mb-3">
                    <span className="flex items-center gap-1"><Calendar size={16} /> {event.date}</span>
                    <span className="flex items-center gap-1"><Clock size={16} /> {event.time}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-[#A0522D] mb-2">{event.title}</h3>
                  <p className="text-[#A0522D]/70 mb-4 text-sm font-medium">{event.location}</p>
                  <p className="text-[#A0522D]/80/70 mb-6 text-sm leading-relaxed">{event.description}</p>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleJoinEvent(event)}
                    disabled={new Date(event.date) < new Date()}
                    className={`w-full py-3 rounded-xl font-bold transition-all border ${new Date(event.date) < new Date() ? 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed' : 'bg-[#A0522D]/5 border-[#A0522D]/30 text-[#A0522D]/70 hover:bg-emerald-600 hover:text-white hover:border-emerald-600'}`}
                  >
                    {new Date(event.date) < new Date() ? 'Event Completed' : t.volunteer.joinEvent}
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- Media Section --- */}
      <section id="media" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-serif italic text-amber-600 mb-12 text-center">Media</h2>
          
          <div className="flex justify-center gap-4 mb-12">
            {(['photo', 'video', 'reel'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveMediaTab(tab)}
                className={`px-8 py-3 rounded-full font-bold transition-all ${activeMediaTab === tab ? 'bg-[#A0522D] text-white shadow-lg' : 'bg-[#A0522D]/5 text-[#A0522D]/70 hover:bg-[#A0522D]/10'}`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}s
              </button>
            ))}
          </div>

          <motion.div
            key={activeMediaTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {activeMediaTab === 'photo' && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {media.filter(m => m.type === 'photo').map((photo) => (
                  <motion.div 
                    key={photo.id}
                    whileHover={{ scale: 1.05 }}
                    className="aspect-square rounded-3xl overflow-hidden shadow-lg cursor-pointer"
                  >
                    <img src={photo.url} alt={photo.title} className="w-full h-full object-cover" loading="lazy" referrerPolicy="no-referrer" />
                  </motion.div>
                ))}
              </div>
            )}

            {activeMediaTab === 'video' && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {media.filter(m => m.type === 'video').map((video) => (
                  <div key={video.id} className="bg-white rounded-3xl overflow-hidden shadow-lg border border-[#A0522D]/10">
                    <div className="aspect-video relative">
                      <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" loading="lazy" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                        <Play className="text-white" size={48} />
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-[#A0522D]">{video.title}</h3>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeMediaTab === 'reel' && (
              <div className="flex overflow-x-auto gap-6 pb-8 snap-x">
                {media.filter(m => m.type === 'reel').map((reel) => (
                  <div key={reel.id} className="min-w-[280px] aspect-[9/16] rounded-3xl overflow-hidden shadow-lg snap-center">
                    <video src={reel.url} className="w-full h-full object-cover" controls loading="lazy" />
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </section>

      {/* --- Testimonials Section --- */}
      <section id="testimonials" className="py-24 bg-[#fcfcf9] overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl md:text-5xl font-serif italic text-amber-600 mb-16 text-center">{t.nav.testimonials}</h2>
          
          <div className="relative flex overflow-hidden">
            <motion.div 
              className="flex gap-8 py-4"
              animate={{ x: [0, -1000] }}
              transition={{ 
                duration: 30, 
                repeat: Infinity, 
                ease: "linear" 
              }}
            >
              {[...testimonials, ...testimonials, ...testimonials].map((test, i) => (
                <div 
                  key={`${test.id}-${i}`} 
                  className="min-w-[350px] bg-white p-10 rounded-[2.5rem] border border-[#A0522D]/10 shadow-[0_10px_40px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-xl transition-shadow"
                >
                  <div>
                    <Quote size={40} className="text-[#A0522D]/20 mb-6" />
                    <p className="text-[#A0522D]/80 text-xl mb-8 italic leading-relaxed">"{test.text}"</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-emerald-100">
                      {test.name[0]}
                    </div>
                    <div>
                      <span className="block font-bold text-[#A0522D] text-lg">{test.name}</span>
                      <span className="text-[#A0522D]/100 text-sm font-medium uppercase tracking-widest">Volunteer</span>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* --- Donation Section --- */}
      <section className="py-24 px-6 text-center bg-white">
        <div className="max-w-xl mx-auto bg-[#A0522D]/5 p-12 rounded-[3rem] shadow-xl border border-[#A0522D]/20">
          <h2 className="text-3xl font-serif italic text-amber-600 mb-8">Support Our Cause</h2>
          <div className="w-48 h-48 bg-white mx-auto rounded-3xl flex items-center justify-center border-2 border-dashed border-[#A0522D]/30 mb-6 shadow-inner">
            <span className="text-[#A0522D]/40 font-bold uppercase tracking-widest text-xs">UPI QR CODE</span>
          </div>
          <p className="text-amber-600 font-medium">Scan to contribute via any UPI App</p>
        </div>
      </section>

      {/* --- Collaborators Section --- */}
      <motion.section 
        id="collaborators" 
        onViewportEnter={() => setCurrentTheme('emerald')}
        onViewportLeave={() => setCurrentTheme('light')}
        className="py-24 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-6">
          <h2 className={`text-4xl md:text-5xl font-serif italic mb-16 text-center transition-colors duration-1000 ${currentTheme === 'emerald' ? 'text-white' : 'text-[#A0522D]'}`}>
            {t.nav.collaborators}
          </h2>
          
          <div className="relative">
            {/* Connecting Line Animation */}
            <div className={`absolute top-1/2 left-0 right-0 h-1 -translate-y-1/2 hidden md:block overflow-hidden transition-colors duration-1000 ${currentTheme === 'emerald' ? 'bg-[#A0522D]/80' : 'bg-[#A0522D]/10'}`}>
              <motion.div 
                animate={{ x: ['-100%', '100%'] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                className="w-1/2 h-full bg-gradient-to-r from-transparent via-[#A0522D]/50 to-transparent"
              />
            </div>
            
            <div className="flex flex-wrap justify-center md:justify-between items-center gap-12 relative z-10">
              {collaborators.map((collab, i) => (
                <motion.div
                  key={collab.id}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="flex flex-col items-center group"
                >
                  <motion.div 
                    whileHover={{ y: -10 }}
                    className="w-28 h-28 rounded-full bg-white border-4 border-[#A0522D]/10 shadow-2xl flex items-center justify-center p-6 group-hover:border-[#A0522D]/100 transition-all duration-500 relative"
                  >
                    <img 
                      src={collab.logo} 
                      alt={collab.name} 
                      className="w-full h-full object-contain grayscale group-hover:grayscale-0 transition-all"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute -inset-2 bg-[#A0522D]/50/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  </motion.div>
                  <span className={`mt-6 font-bold text-sm uppercase tracking-widest transition-colors duration-1000 ${currentTheme === 'emerald' ? 'text-[#A0522D]/20' : 'text-[#A0522D]/80'}`}>
                    {collab.name}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      {/* --- Footer --- */}
        <motion.footer 
        id="contact" 
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="bg-[#A0522D]/5 text-[#A0522D] pt-24 pb-12 px-6"
      >
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
              <div className="col-span-1 md:col-span-2">
                <h2 className="text-4xl font-serif italic mb-6 font-bold text-emerald-600">{lang === 'en' ? 'Madurai Manvasam' : 'மதுரை மண்வாசம்'}</h2>
                <p className="text-[#A0522D] max-w-md mb-8 font-bold">
                  {lang === 'en' ? 'A community initiative for a cleaner and greener Madurai.' : 'தூய்மையான மற்றும் பசுமையான மதுரைக்கான ஒரு சமூக முன்முயற்சி.'}
                </p>
                <div className="flex gap-4">
                  <a href="#" className="w-12 h-12 bg-[#A0522D]/20 rounded-full flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
                    <Instagram size={24} />
                  </a>
                </div>
              </div>
              
              <div>
                <h4 className="font-bold uppercase tracking-widest mb-6 text-[#A0522D]">Quick Links</h4>
                <ul className="space-y-4 text-[#A0522D] font-bold">
                  <li><button onClick={() => scrollToSection('home')} className="hover:text-emerald-600 transition-colors">Home</button></li>
                  <li><button onClick={() => scrollToSection('about')} className="hover:text-emerald-600 transition-colors">About</button></li>
                  <li><button onClick={() => scrollToSection('events')} className="hover:text-emerald-600 transition-colors">Events</button></li>
                  <li><button onClick={() => setShowJoinModal(true)} className="hover:text-emerald-600 transition-colors">Volunteer</button></li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold uppercase tracking-widest mb-6 text-[#A0522D]">Legal</h4>
                <ul className="space-y-4 text-[#A0522D] font-bold">
                  <li><button onClick={() => scrollToSection('privacy')} className="hover:text-emerald-600 transition-colors">{t.nav.privacy}</button></li>
                  <li><button onClick={() => scrollToSection('terms')} className="hover:text-emerald-600 transition-colors">{t.nav.terms}</button></li>
                  <li><button onClick={() => setShowAdminLogin(true)} className="hover:text-emerald-600 transition-colors">Admin Login</button></li>
                </ul>
              </div>
            </div>

            {/* Privacy & Terms Detailed Sections */}
            <div id="privacy" className="p-8 bg-stone-200/50 rounded-2xl mb-8">
              <h3 className="text-2xl font-sans mb-4 font-bold text-amber-900">{t.privacy.title}</h3>
              <p className="text-stone-700 leading-relaxed font-medium">{t.privacy.content}</p>
            </div>
            
            <div id="terms" className="p-8 bg-stone-200/50 rounded-2xl mb-8">
              <h3 className="text-2xl font-sans mb-4 font-bold text-amber-900">{t.terms.title}</h3>
              <p className="text-stone-700 leading-relaxed font-medium">{t.terms.content}</p>
            </div>

            <div className="pt-8 border-t border-[#A0522D]/20 text-center flex flex-col md:flex-row items-center justify-between gap-4 text-amber-700/70 text-sm bg-stone-100 px-6 py-4 rounded-b-2xl">
              <div className="text-stone-700">© {new Date().getFullYear()} Madurai Manvasam. All rights reserved.</div>
              <button 
                onClick={() => window.open('https://brandwe4.com', '_blank')}
                className="text-amber-700 hover:text-amber-900 transition-colors cursor-pointer font-bold tracking-wider uppercase"
              >
                Designed by BrandWE4
              </button>
            </div>
          </div>
        </motion.footer>
      </motion.main>
    </AnimatePresence>

      {/* --- Video Player Modal --- */}
      <AnimatePresence>
        {selectedVideo && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[150] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-12"
          >
            <button 
              onClick={() => setSelectedVideo(null)}
              className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors z-20"
            >
              <X size={40} />
            </button>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className={`relative w-full ${selectedVideo.type === 'reel' ? 'max-w-[400px] aspect-[9/16]' : 'max-w-5xl aspect-video'} rounded-3xl overflow-hidden shadow-[0_0_100px_rgba(16,185,129,0.2)] bg-black`}
            >
              <video 
                ref={modalVideoRef}
                src={selectedVideo.url} 
                autoPlay 
                playsInline
                className="w-full h-full object-contain"
              />
              {/* Custom Control Bar */}
              <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-4 flex items-center justify-center gap-4 text-white">
                <button onClick={() => { if (modalVideoRef.current) modalVideoRef.current.playbackRate = 0.5 }}>0.5x</button>
                <button onClick={() => { if (modalVideoRef.current) modalVideoRef.current.playbackRate = 1 }}>1x</button>
                <button onClick={() => { if (modalVideoRef.current) modalVideoRef.current.playbackRate = 2 }}>2x</button>
                <button onClick={() => { if (modalVideoRef.current) modalVideoRef.current.loop = !modalVideoRef.current.loop }}>Loop</button>
                <button onClick={() => { 
                  if (modalVideoRef.current && modalVideoRef.current.textTracks.length > 0) {
                    modalVideoRef.current.textTracks[0].mode = modalVideoRef.current.textTracks[0].mode === 'showing' ? 'hidden' : 'showing';
                  } else {
                    alert('No captions available');
                  }
                }}>Captions</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Admin Login Modal --- */}
      <AnimatePresence>
        {showAdminLogin && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white rounded-[2rem] p-8 md:p-12 max-w-md w-full shadow-2xl relative"
            >
              <button 
                onClick={() => setShowAdminLogin(false)}
                className="absolute top-6 right-6 text-[#A0522D] hover:text-emerald-600"
              >
                <X size={24} />
              </button>
              
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-[#A0522D]/10 rounded-2xl flex items-center justify-center text-amber-600 mx-auto mb-4">
                  <Lock size={32} />
                </div>
                <h2 className="text-3xl font-serif italic text-amber-600">{t.admin.login}</h2>
              </div>

              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div className="bg-amber-50 p-6 rounded-2xl border border-amber-100 mb-6">
                  <p className="text-amber-800 text-sm leading-relaxed text-center">
                    {lang === 'en' 
                      ? "Admin access is restricted to authorized Google accounts. Please sign in with your admin email."
                      : "அட்மின் அணுகல் அங்கீகரிக்கப்பட்ட கூகிள் கணக்குகளுக்கு மட்டுமே. உங்கள் அட்மின் மின்னஞ்சல் மூலம் உள்நுழையவும்."}
                  </p>
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-[#A0522D] text-white py-4 rounded-2xl font-bold hover:bg-[#8B4513] transition-all shadow-lg hover:shadow-xl active:scale-[0.98] flex items-center justify-center gap-3"
                >
                  <Globe size={20} />
                  {lang === 'en' ? "Sign in with Google" : "கூகிள் மூலம் உள்நுழையவும்"}
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Admin Dashboard Modal --- */}
      <AnimatePresence>
        {showAdminDashboard && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-[#fcfcf9] overflow-hidden flex flex-col"
          >
            {/* Admin Header */}
            <div className="bg-white border-b border-[#A0522D]/20 px-6 py-4 flex justify-between items-center shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-[#A0522D] rounded-xl flex items-center justify-center text-white font-bold">A</div>
                <h2 className="text-2xl font-serif italic text-[#A0522D]">{t.admin.dashboard}</h2>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={fetchVolunteerData}
                  className="flex items-center gap-2 px-6 py-2 bg-[#A0522D]/5 text-[#A0522D]/70 rounded-full font-bold hover:bg-[#A0522D]/10 transition-all"
                  title="Refresh Data"
                  disabled={isFetching}
                >
                  <RefreshCw size={18} className={isFetching ? 'animate-spin' : ''} /> {isFetching ? 'Fetching...' : 'Refresh'}
                </button>
                <button 
                  onClick={() => setShowAdminDashboard(false)}
                  className="flex items-center gap-2 px-6 py-2 bg-[#A0522D]/5 text-[#A0522D]/70 rounded-full font-bold hover:bg-[#A0522D]/10 transition-all"
                >
                  <X size={18} /> {lang === 'en' ? 'Close' : 'மூடு'}
                </button>
                <button 
                  onClick={handleAdminLogout}
                  className="flex items-center gap-2 px-6 py-2 bg-red-50 text-red-600 rounded-full font-bold hover:bg-red-100 transition-all"
                >
                  <LogOut size={18} /> {t.admin.logout}
                </button>
              </div>
            </div>

            <div className="flex flex-1 overflow-hidden">
              {/* Admin Sidebar */}
              <div className="w-64 bg-white border-r border-[#A0522D]/20 p-6 hidden md:flex flex-col gap-2">
                {[
                  { id: 'overview', label: 'Overview', icon: <Globe size={18} /> },
                  { id: 'volunteers', label: 'Volunteers', icon: <Users size={18} /> },
                  { id: 'records', label: 'Event Records', icon: <ClipboardList size={18} /> },
                  { id: 'media', label: t.admin.media, icon: <ImageIcon size={18} /> },
                  { id: 'events', label: t.admin.events, icon: <Calendar size={18} /> },
                  { id: 'testimonials', label: t.admin.testimonials, icon: <Quote size={18} /> },
                  { id: 'sponsors', label: t.admin.sponsors, icon: <Award size={18} /> },
                  { id: 'collaborators', label: t.admin.collaborators, icon: <Handshake size={18} /> },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveAdminTab(tab.id as any)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm transition-all ${activeAdminTab === tab.id ? 'bg-[#A0522D] text-white shadow-lg shadow-[#A0522D]/20' : 'text-[#A0522D]/70 hover:bg-[#A0522D]/5'}`}
                  >
                    {tab.icon}
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Admin Content Area */}
              <div className="flex-1 overflow-y-auto p-6 md:p-10 bg-[#fcfcf9]">
                {activeAdminTab === 'overview' && (
                  <div className="max-w-6xl mx-auto space-y-12">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5 relative overflow-hidden group hover:shadow-2xl transition-all"
                      >
                        <Calendar className="absolute -right-4 -bottom-4 w-24 h-24 text-[#A0522D]/10 group-hover:scale-110 transition-transform opacity-50" />
                        <p className="text-amber-600 font-bold uppercase tracking-widest text-[10px] mb-2">Total Events</p>
                        <p className="text-5xl font-serif italic text-amber-600"><CountUp end={events.length} /></p>
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5 relative overflow-hidden group hover:shadow-2xl transition-all"
                      >
                        <Users className="absolute -right-4 -bottom-4 w-24 h-24 text-[#A0522D]/10 group-hover:scale-110 transition-transform opacity-50" />
                        <p className="text-amber-600 font-bold uppercase tracking-widest text-[10px] mb-2">Total Volunteers</p>
                        <p className="text-5xl font-serif italic text-amber-600">
                          <CountUp end={new Set(volunteerRecords.map(r => r.phone)).size} />
                        </p>
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="bg-[#A0522D] text-white p-8 rounded-[2.5rem] shadow-xl shadow-[#A0522D]/20 relative overflow-hidden group hover:shadow-2xl transition-all"
                      >
                        <Clock className="absolute -right-4 -bottom-4 w-24 h-24 text-white/10 group-hover:scale-110 transition-transform" />
                        <p className="text-[#A0522D]/40 font-bold uppercase tracking-widest text-[10px] mb-2">Active Events</p>
                        <p className="text-5xl font-serif italic">
                          <CountUp end={events.filter(e => new Date(e.date) >= new Date()).length} />
                        </p>
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5 relative overflow-hidden group hover:shadow-2xl transition-all"
                      >
                        <Award className="absolute -right-4 -bottom-4 w-24 h-24 text-[#A0522D]/10 group-hover:scale-110 transition-transform opacity-50" />
                        <p className="text-amber-600 font-bold uppercase tracking-widest text-[10px] mb-2">Completed</p>
                        <p className="text-5xl font-serif italic text-amber-600">
                          <CountUp end={events.filter(e => new Date(e.date) < new Date()).length} />
                        </p>
                      </motion.div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5">
                        <h3 className="text-xl font-serif italic text-[#A0522D] mb-8">Volunteers per Event</h3>
                        <div className="h-[300px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={events.map(e => ({
                              name: e.title.length > 15 ? e.title.substring(0, 15) + '...' : e.title,
                              volunteers: volunteerRecords.filter(r => r.eventId === e.id).length
                            }))}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0fdf4" />
                              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#064e3b' }} />
                              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#064e3b' }} />
                              <Tooltip 
                                contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                                cursor={{ fill: '#f0fdf4' }}
                              />
                              <Bar dataKey="volunteers" fill="#064e3b" radius={[4, 4, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      <div className="bg-white p-10 rounded-[3rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5 flex flex-col justify-center text-center">
                        <div className="w-20 h-20 bg-[#A0522D]/5 rounded-3xl flex items-center justify-center text-[#A0522D] mx-auto mb-6">
                          <Globe size={32} />
                        </div>
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-4">Community Reach</h3>
                        <p className="text-amber-600 text-sm leading-relaxed mb-8">Your impact is growing! You've successfully organized {events.length} events across various locations in Madurai.</p>
                        <div className="flex items-center justify-center gap-2 text-[#A0522D] font-bold">
                          <span className="text-3xl font-serif italic">{new Set(volunteerRecords.map(r => r.phone)).size}</span>
                          <span className="text-xs uppercase tracking-widest text-amber-600">Total People</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}


                {activeAdminTab === 'volunteers' && (
                  <div className="max-w-6xl mx-auto space-y-12">
                    {/* 1. All Volunteers Section */}
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl"
                    >
                      <div className="flex items-center justify-between mb-8">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] flex items-center gap-3">
                          <Users className="text-amber-600" /> All Volunteers
                        </h3>
                        <span className="px-4 py-1 bg-[#A0522D]/5 text-[#A0522D]/70 rounded-full text-[10px] font-bold uppercase tracking-widest">
                          {volunteerRecords.length} Total
                        </span>
                      </div>
                      
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-[#A0522D]/5 border-b border-[#A0522D]/20">
                              <th className="px-6 py-4 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Name</th>
                              <th className="px-6 py-4 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Phone</th>
                              <th className="px-6 py-4 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Age</th>
                              <th className="px-6 py-4 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Gender</th>
                              <th className="px-6 py-4 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Area</th>
                              <th className="px-6 py-4 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Event Joined</th>
                            </tr>
                          </thead>
                          <tbody>
                            {volunteerRecords.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="px-6 py-10 text-center text-[#A0522D]/50 italic">No volunteers yet.</td>
                              </tr>
                            ) : (
                              volunteerRecords.map((v) => (
                                <tr key={v.id} className="border-b border-[#A0522D]/10 hover:bg-[#A0522D]/5/20 transition-colors">
                                  <td className="px-6 py-4 font-bold text-[#A0522D]">{v.userName}</td>
                                  <td className="px-6 py-4 text-[#A0522D]/70 text-sm">{v.phone}</td>
                                  <td className="px-6 py-4 text-amber-600 text-sm">{v.age}</td>
                                  <td className="px-6 py-4 text-amber-600 text-sm">{v.gender}</td>
                                  <td className="px-6 py-4 text-amber-600 text-sm">{v.area}</td>
                                  <td className="px-6 py-4 text-[#A0522D]/100 text-xs font-medium">{v.eventName}</td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </motion.div>
                  </div>
                )}


                {activeAdminTab === 'records' && (
                  <div className="max-w-5xl mx-auto">
                    <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl">
                      <div className="flex justify-between items-center mb-8">
                        <div className="flex flex-col">
                          <h3 className="text-2xl font-serif italic text-[#A0522D] flex items-center gap-3">
                            <ClipboardList className="text-amber-600" /> Event Participation Records
                          </h3>
                          {!selectedAdminEventId && (
                            <p className="text-xs text-amber-600 font-bold mt-1 uppercase tracking-widest">
                              Total Unique Volunteers: {new Set(volunteerRecords.map(r => r.phone)).size}
                            </p>
                          )}
                        </div>
                        {selectedAdminEventId && (
                          <button 
                            onClick={() => setSelectedAdminEventId(null)}
                            className="text-amber-600 font-bold text-sm hover:underline flex items-center gap-1"
                          >
                            <ChevronLeft size={16} /> Back to Events
                          </button>
                        )}
                      </div>
                      
                      {events.length === 0 ? (
                        <div className="text-center py-20 bg-[#A0522D]/5/30 rounded-3xl border border-dashed border-[#A0522D]/30">
                          <Calendar size={48} className="text-[#A0522D]/30 mx-auto mb-4" />
                          <p className="text-[#A0522D]/50 font-medium">No events to show records for.</p>
                        </div>
                      ) : !selectedAdminEventId ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {events.map((e) => {
                            const count = volunteerRecords.filter(r => r.eventId === e.id).length;
                            return (
                              <button
                                key={e.id}
                                onClick={() => setSelectedAdminEventId(e.id)}
                                className="text-left p-6 bg-[#A0522D]/5/50 rounded-3xl border border-[#A0522D]/20 hover:border-[#A0522D]/40 transition-all group"
                              >
                                <div className="flex justify-between items-start mb-4">
                                  <div className="w-12 h-12 rounded-xl overflow-hidden shadow-sm">
                                    <img src={e.image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                  </div>
                                  <div className="flex flex-col items-end gap-1">
                                    <span className="px-3 py-1 bg-[#A0522D] text-white rounded-full text-[10px] font-bold uppercase tracking-widest">
                                      {count} Joined
                                    </span>
                                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-widest ${new Date(e.date) < new Date() ? 'bg-gray-100 text-gray-500' : 'bg-[#A0522D]/10 text-[#A0522D]/70'}`}>
                                      {new Date(e.date) < new Date() ? 'Completed' : 'Upcoming'}
                                    </span>
                                  </div>
                                </div>
                                <h4 className="font-bold text-[#A0522D] text-lg mb-1">{e.title}</h4>
                                <p className="text-xs text-amber-600 font-medium">{e.date} • {e.location}</p>
                                <div className="mt-4 flex items-center gap-2 text-[#A0522D]/70 font-bold text-xs group-hover:translate-x-1 transition-transform">
                                  View Volunteers <ChevronRight size={14} />
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      ) : (
                        <div>
                          {events.filter(e => e.id === selectedAdminEventId).map(e => {
                            const eventVolunteers = volunteerRecords.filter(r => r.eventId === e.id);
                            const isPast = new Date(e.date) < new Date();
                            return (
                              <div key={e.id} className="space-y-8">
                                <div className="bg-[#A0522D]/5/30 p-8 rounded-[2.5rem] border border-[#A0522D]/20">
                                  <div className="flex flex-col md:flex-row justify-between items-start gap-6 mb-8">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-3 mb-2">
                                        <h4 className="font-bold text-[#A0522D] text-3xl">{e.title}</h4>
                                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${isPast ? 'bg-gray-100 text-gray-600' : 'bg-[#A0522D]/10 text-[#A0522D]/70'}`}>
                                          {isPast ? 'Completed' : 'Upcoming'}
                                        </span>
                                      </div>
                                      <p className="text-amber-600 font-medium flex items-center gap-4 text-sm">
                                        <span className="flex items-center gap-1"><Calendar size={16} /> {e.date}</span>
                                        <span className="flex items-center gap-1"><Clock size={16} /> {e.time}</span>
                                        <span className="flex items-center gap-1"><MapPin size={16} /> {e.location}</span>
                                      </p>
                                    </div>
                                    <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-[#A0522D]/10 text-center">
                                      <p className="text-[10px] font-bold text-[#A0522D]/100 uppercase tracking-widest mb-1">Total Volunteers</p>
                                      <p className="text-3xl font-serif italic text-amber-600">{eventVolunteers.length}</p>
                                    </div>
                                  </div>
                                  <div className="bg-white/50 p-6 rounded-2xl border border-[#A0522D]/10">
                                    <h5 className="text-xs font-bold text-[#A0522D]/80 uppercase tracking-widest mb-3">Description</h5>
                                    <p className="text-[#A0522D]/70 leading-relaxed text-sm">{e.description}</p>
                                  </div>
                                </div>
                                
                                <div className="space-y-4">
                                  <div className="flex items-center justify-between px-4">
                                    <h5 className="text-lg font-serif italic text-[#A0522D]">Volunteer List</h5>
                                    <span className="text-xs font-bold text-[#A0522D]/100 uppercase tracking-widest">{eventVolunteers.length} People</span>
                                  </div>
                                  
                                  <div className="bg-white border border-[#A0522D]/10 rounded-[2rem] overflow-hidden shadow-xl shadow-[#A0522D]/5">
                                    <div className="max-h-[400px] overflow-y-auto">
                                      <table className="w-full text-left border-collapse">
                                        <thead className="sticky top-0 z-10">
                                          <tr className="bg-[#A0522D]/5 border-b border-[#A0522D]/20">
                                            <th className="px-8 py-5 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Volunteer Name</th>
                                            <th className="px-8 py-5 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Phone Number</th>
                                            <th className="px-8 py-5 font-bold text-[#A0522D]/80 uppercase tracking-widest text-[10px]">Joined Date</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {eventVolunteers.length === 0 ? (
                                            <tr>
                                              <td colSpan={3} className="px-8 py-20 text-center text-[#A0522D]/50 italic">No volunteers joined this event yet.</td>
                                            </tr>
                                          ) : (
                                            eventVolunteers.map((v, idx) => {
                                              return (
                                                <tr key={idx} className="border-b border-[#A0522D]/10 hover:bg-[#A0522D]/5/20 transition-colors">
                                                  <td className="px-8 py-5">
                                                    <div className="flex items-center gap-4">
                                                      <div className="w-10 h-10 bg-[#A0522D]/10 rounded-xl flex items-center justify-center text-[#A0522D]/70 font-bold text-sm uppercase">
                                                        {v.userName[0]}
                                                      </div>
                                                      <span className="font-bold text-[#A0522D]">{v.userName}</span>
                                                    </div>
                                                  </td>
                                                  <td className="px-8 py-5 text-[#A0522D]/70 font-medium">{v.phone}</td>
                                                  <td className="px-8 py-5 text-[#A0522D]/100 text-xs font-medium">
                                                    {new Date(v.joinedAt).toLocaleDateString()} at {new Date(v.joinedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                  </td>
                                                </tr>
                                              );
                                            })
                                          )}
                                        </tbody>
                                      </table>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeAdminTab === 'media' && (
                  <div className="max-w-5xl mx-auto space-y-8">
                    <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl">
                      <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8 flex items-center gap-3">
                        <ImageIcon className="text-amber-600" /> Media Management
                      </h3>
                      
                      <div className="grid md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <div>
                            <label className="block text-sm font-bold text-[#A0522D]/80 mb-3 uppercase tracking-wider">Select Media Type</label>
                            <div className="flex gap-3">
                              {(['photo', 'reel', 'video'] as const).map((type) => (
                                <button 
                                  key={type}
                                  onClick={() => setNewMediaType(type)}
                                  className={`flex-1 py-3 rounded-xl text-sm font-bold capitalize transition-all flex flex-col items-center gap-2 border-2 ${newMediaType === type ? 'bg-[#A0522D] text-white border-[#A0522D] shadow-lg' : 'bg-white text-amber-600 border-[#A0522D]/10 hover:border-[#A0522D]/30'}`}
                                >
                                  {type === 'photo' ? <ImageIcon size={20} /> : type === 'reel' ? <Film size={20} /> : <Play size={20} />}
                                  {type}
                                </button>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-bold text-[#A0522D]/80 mb-3 uppercase tracking-wider">Or Upload File</label>
                            <input 
                              type="file"
                              accept="image/*,video/*"
                              className="w-full px-6 py-4 bg-[#A0522D]/5 rounded-2xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 transition-all" 
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;

                                // File validation
                                if (file.size > 20 * 1024 * 1024) {
                                  alert("File size too large. Please upload files under 20MB.");
                                  return;
                                }

                                setIsUploading(true);
                                setUploadSuccess(false);
                                setUploadProgress(0);
                                
                                let fileToUpload = file;
                                if (file.type.startsWith('image/')) {
                                  try {
                                    fileToUpload = await imageCompression(file, { maxSizeMB: 1, maxWidthOrHeight: 1920 });
                                  } catch (error) {
                                    console.error("Compression failed:", error);
                                  }
                                }

                                setPreviewUrl(URL.createObjectURL(fileToUpload));
                                const storageRef = ref(storage, `media/${Date.now()}_${fileToUpload.name}`);
                                const uploadTask = uploadBytesResumable(storageRef, fileToUpload);
                                
                                uploadTask.on('state_changed', 
                                  (snapshot) => {
                                    const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                                    setUploadProgress(progress);
                                  }, 
                                  (error) => {
                                    console.error("Upload failed:", error);
                                    alert("Upload failed. Please check your Firebase Storage permissions.");
                                    setIsUploading(false);
                                    setPreviewUrl(null);
                                  }, 
                                  async () => {
                                    const url = await getDownloadURL(uploadTask.snapshot.ref);
                                    setNewMediaUrl(url);
                                    setUploadSuccess(true);
                                    setIsUploading(false);
                                  }
                                );
                              }}
                            />
                            <p className="mt-2 text-[10px] text-[#A0522D]/50 italic">Upload a file to automatically generate a URL.</p>
                            {previewUrl && (
                              <div className="mt-2">
                                <p className="text-sm text-[#A0522D]/80">Preview:</p>
                                {newMediaType === 'photo' ? (
                                  <img src={previewUrl} alt="Preview" className="w-32 h-32 object-cover rounded-lg mt-1" />
                                ) : (
                                  <video src={previewUrl} className="w-32 h-32 object-cover rounded-lg mt-1" controls />
                                )}
                              </div>
                            )}
                            {isUploading && (
                              <div className="mt-2">
                                <p className="text-sm text-amber-600">Uploading: {Math.round(uploadProgress)}%</p>
                                <div className="w-full bg-amber-100 rounded-full h-2 mt-1">
                                  <div className="bg-amber-600 h-2 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
                                </div>
                              </div>
                            )}
                            {uploadSuccess && <p className="mt-2 text-sm text-emerald-600 font-bold">Upload Successfully!</p>}
                          </div>
                          
                          <div>
                            <label className="block text-sm font-bold text-[#A0522D]/80 mb-3 uppercase tracking-wider">Media Title</label>
                            <input 
                              className="w-full px-6 py-4 bg-[#A0522D]/5 rounded-2xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 transition-all" 
                              placeholder="Enter media title..." 
                              value={newMediaTitle}
                              onChange={(e) => setNewMediaTitle(e.target.value)}
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-bold text-[#A0522D]/80 mb-3 uppercase tracking-wider">Media URL</label>
                            <input 
                              className="w-full px-6 py-4 bg-[#A0522D]/5 rounded-2xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 transition-all" 
                              placeholder="Paste image or video link here..." 
                              value={newMediaUrl}
                              onChange={(e) => {
                                setNewMediaUrl(e.target.value);
                                setUploadSuccess(false);
                              }}
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-bold text-[#A0522D]/80 mb-3 uppercase tracking-wider">Thumbnail URL (Optional)</label>
                            <input 
                              className="w-full px-6 py-4 bg-[#A0522D]/5 rounded-2xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 transition-all" 
                              placeholder="Paste thumbnail image link here..." 
                              value={newMediaThumbnail}
                              onChange={(e) => setNewMediaThumbnail(e.target.value)}
                            />
                            <p className="mt-2 text-[10px] text-[#A0522D]/50 italic">Tip: If left empty, a placeholder will be used for videos/reels.</p>
                          </div>
                          
                          <button 
                            onClick={handleAddMedia}
                            className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-bold text-lg shadow-xl shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center justify-center gap-3"
                          >
                            <Plus size={24} /> Upload to {newMediaType}s
                          </button>
                        </div>

                        <div className="bg-[#A0522D]/5/50 rounded-3xl p-6 border border-[#A0522D]/20 flex flex-col items-center justify-center text-center">
                          {newMediaUrl ? (
                            <div className="w-full aspect-video rounded-2xl overflow-hidden shadow-lg bg-black">
                              {newMediaType === 'photo' ? (
                                <img src={newMediaUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center text-white/50">
                                  <Play size={48} />
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="space-y-4">
                              <div className="w-20 h-20 bg-[#A0522D]/10 rounded-full flex items-center justify-center text-[#A0522D]/40 mx-auto">
                                <ImageIcon size={40} />
                              </div>
                              <p className="text-[#A0522D]/50 font-medium">Preview will appear here</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl">
                      <h4 className="text-xl font-serif italic text-[#A0522D] mb-8">Uploaded Media Library</h4>
                      
                      {media.length === 0 ? (
                        <div className="text-center py-16 bg-[#A0522D]/5/30 rounded-3xl border border-dashed border-[#A0522D]/30">
                          <ImageIcon size={48} className="text-[#A0522D]/30 mx-auto mb-4" />
                          <p className="text-[#A0522D]/50 font-medium">No media uploaded yet.</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                          {media.map((m) => (
                            <div key={m.id} className="group relative aspect-square rounded-2xl overflow-hidden shadow-md border border-[#A0522D]/10">
                              <img src={m.thumbnail} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              <div className="absolute inset-0 bg-[#A0522D]/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4 text-center">
                                <span className="text-[10px] font-bold text-white uppercase tracking-widest bg-emerald-600 px-2 py-1 rounded-full mb-2">{m.type}</span>
                                <button 
                                  onClick={() => handleDeleteMedia(m.id)}
                                  className="p-3 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors shadow-lg"
                                >
                                  <Trash2 size={20} />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {activeAdminTab === 'events' && (
                  <div className="max-w-5xl mx-auto grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl sticky top-0">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8 flex items-center gap-3">
                          <Plus className="text-amber-600" /> {t.admin.addEvent}
                        </h3>
                        <div className="space-y-4">
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Event Title" 
                            value={newEvent.title}
                            onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                          />
                          <input 
                            type="date"
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            value={newEvent.date}
                            onChange={(e) => setNewEvent({...newEvent, date: e.target.value})}
                          />
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Event Time (e.g. 07:00 AM)" 
                            value={newEvent.time}
                            onChange={(e) => setNewEvent({...newEvent, time: e.target.value})}
                          />
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Location" 
                            value={newEvent.location}
                            onChange={(e) => setNewEvent({...newEvent, location: e.target.value})}
                          />
                          <textarea 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 h-24" 
                            placeholder="Short Description" 
                            value={newEvent.description}
                            onChange={(e) => setNewEvent({...newEvent, description: e.target.value})}
                          />
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Event Image URL (Optional)" 
                            value={newEvent.image}
                            onChange={(e) => setNewEvent({...newEvent, image: e.target.value})}
                          />
                          <button 
                            onClick={handleAddEvent}
                            className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                          >
                            Create Event
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="lg:col-span-2">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5">
                        <div className="flex flex-col gap-6 mb-8">
                          <div className="flex items-center justify-between">
                            <h3 className="text-2xl font-serif italic text-[#A0522D]">Existing Events</h3>
                            <span className="px-4 py-1 bg-[#A0522D]/5 text-[#A0522D]/70 rounded-full text-[10px] font-bold uppercase tracking-widest">
                              {events.length} Total
                            </span>
                          </div>
                          
                          <div className="flex flex-wrap gap-4">
                            <div className="flex-1 min-w-[150px]">
                              <label className="block text-[10px] font-bold text-amber-600 uppercase tracking-widest mb-2">Date Filter</label>
                              <select 
                                value={adminEventFilter}
                                onChange={(e) => setAdminEventFilter(e.target.value as any)}
                                className="w-full px-4 py-2 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 text-sm font-bold text-[#A0522D] focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60"
                              >
                                <option value="all">All Dates</option>
                                <option value="today">Today</option>
                                <option value="upcoming">Upcoming</option>
                                <option value="completed">Completed</option>
                              </select>
                            </div>
                            <div className="flex-1 min-w-[150px]">
                              <label className="block text-[10px] font-bold text-amber-600 uppercase tracking-widest mb-2">Volunteer Count</label>
                              <select 
                                value={adminVolunteerFilter}
                                onChange={(e) => setAdminVolunteerFilter(e.target.value as any)}
                                className="w-full px-4 py-2 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 text-sm font-bold text-[#A0522D] focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60"
                              >
                                <option value="all">Any Count</option>
                                <option value="low">Low (0-10)</option>
                                <option value="medium">Medium (10-50)</option>
                                <option value="high">High (50+)</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        
                        {events.length === 0 ? (
                          <div className="text-center py-20 bg-[#A0522D]/5/30 rounded-3xl border border-dashed border-[#A0522D]/30">
                            <Calendar size={48} className="text-[#A0522D]/30 mx-auto mb-4" />
                            <p className="text-[#A0522D]/50 font-medium">No events scheduled yet.</p>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {events
                              .filter(e => {
                                // Date Filter
                                if (adminEventFilter !== 'all') {
                                  const eventDate = new Date(e.date).toDateString();
                                  const today = new Date().toDateString();
                                  const isPast = new Date(e.date) < new Date();
                                  
                                  if (adminEventFilter === 'today' && eventDate !== today) return false;
                                  if (adminEventFilter === 'upcoming' && isPast) return false;
                                  if (adminEventFilter === 'completed' && !isPast) return false;
                                }

                                // Volunteer Filter
                                if (adminVolunteerFilter !== 'all') {
                                  const count = volunteerRecords.filter(r => r.eventId === e.id).length;
                                  if (adminVolunteerFilter === 'low' && count > 10) return false;
                                  if (adminVolunteerFilter === 'medium' && (count <= 10 || count > 50)) return false;
                                  if (adminVolunteerFilter === 'high' && count <= 50) return false;
                                }

                                return true;
                              })
                              .map((e) => {
                                const count = volunteerRecords.filter(r => r.eventId === e.id).length;
                                const isPast = new Date(e.date) < new Date();
                                return (
                                  <div key={e.id} className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-[#A0522D]/5/30 rounded-3xl border border-[#A0522D]/20 group hover:bg-white hover:shadow-xl hover:shadow-[#A0522D]/5 transition-all gap-6">
                                    <div className="flex items-center gap-6">
                                      <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-md flex-shrink-0">
                                        <img src={e.image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      </div>
                                      <div>
                                        <div className="flex items-center gap-2 mb-1">
                                          <h4 className="font-bold text-[#A0522D] text-lg">{e.title}</h4>
                                          <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-widest ${isPast ? 'bg-gray-100 text-gray-500' : 'bg-[#A0522D]/10 text-[#A0522D]/70'}`}>
                                            {isPast ? 'Completed' : 'Upcoming'}
                                          </span>
                                        </div>
                                        <p className="text-sm text-amber-600 font-medium flex items-center gap-2">
                                          <Calendar size={14} /> {e.date} • <Clock size={14} /> {e.time} • <MapPin size={14} /> {e.location}
                                        </p>
                                        <p className="text-[10px] text-[#A0522D]/50 font-bold uppercase tracking-widest mt-2 flex items-center gap-1">
                                          <Users size={12} /> {count} Volunteers Joined
                                        </p>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <button 
                                        onClick={() => {
                                          setActiveAdminTab('records');
                                          setSelectedAdminEventId(e.id);
                                        }}
                                        className="px-6 py-2 bg-white text-[#A0522D] border border-[#A0522D]/20 rounded-xl font-bold text-sm hover:bg-[#A0522D] hover:text-white transition-all shadow-sm"
                                      >
                                        View Details
                                      </button>
                                      <button 
                                        onClick={() => handleDeleteEvent(e.id)}
                                        className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                                      >
                                        <Trash2 size={20} />
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {activeAdminTab === 'sponsors' && (
                  <div className="max-w-5xl mx-auto grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl sticky top-0">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8 flex items-center gap-3">
                          <Award className="text-amber-600" /> {t.admin.addSponsor}
                        </h3>
                        <div className="space-y-4">
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Sponsor Name" 
                            value={newSponsor.name}
                            onChange={(e) => setNewSponsor({...newSponsor, name: e.target.value})}
                          />
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Logo URL" 
                            value={newSponsor.logo}
                            onChange={(e) => setNewSponsor({...newSponsor, logo: e.target.value})}
                          />
                          <button 
                            onClick={handleAddSponsor}
                            className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                          >
                            Add Sponsor
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="lg:col-span-2">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8">Existing Sponsors</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                          {sponsors.map((s) => (
                            <div key={s.id} className="p-6 bg-[#A0522D]/5/50 rounded-3xl border border-[#A0522D]/20 group relative">
                              <img src={s.logo} alt={s.name} className="w-full h-auto mb-4" referrerPolicy="no-referrer" />
                              <p className="text-center font-bold text-[#A0522D] text-sm">{s.name}</p>
                              <button 
                                onClick={() => handleDeleteSponsor(s.id)}
                                className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeAdminTab === 'collaborators' && (
                  <div className="max-w-5xl mx-auto grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl sticky top-0">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8 flex items-center gap-3">
                          <Handshake className="text-amber-600" /> {t.admin.addCollaborator}
                        </h3>
                        <div className="space-y-4">
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Collaborator Name" 
                            value={newCollaborator.name}
                            onChange={(e) => setNewCollaborator({...newCollaborator, name: e.target.value})}
                          />
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Logo URL" 
                            value={newCollaborator.logo}
                            onChange={(e) => setNewCollaborator({...newCollaborator, logo: e.target.value})}
                          />
                          <button 
                            onClick={handleAddCollaborator}
                            className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                          >
                            Add Collaborator
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="lg:col-span-2">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/10 shadow-xl shadow-[#A0522D]/5">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8">Existing Collaborators</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                          {collaborators.map((c) => (
                            <div key={c.id} className="p-6 bg-[#A0522D]/5/50 rounded-3xl border border-[#A0522D]/20 group relative">
                              <div className="w-20 h-20 mx-auto bg-white rounded-full flex items-center justify-center p-4 mb-4 border border-[#A0522D]/10">
                                <img src={c.logo} alt={c.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                              </div>
                              <p className="text-center font-bold text-[#A0522D] text-sm">{c.name}</p>
                              <button 
                                onClick={() => handleDeleteCollaborator(c.id)}
                                className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                {activeAdminTab === 'testimonials' && (
                  <div className="max-w-5xl mx-auto grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl sticky top-0">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8 flex items-center gap-3">
                          <Quote className="text-amber-600" /> {t.admin.addTestimonial}
                        </h3>
                        <div className="space-y-4">
                          <textarea 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60 h-40" 
                            placeholder="Testimonial Text" 
                            value={newTestimonial.text}
                            onChange={(e) => setNewTestimonial({...newTestimonial, text: e.target.value})}
                          />
                          <input 
                            className="w-full px-5 py-4 bg-[#A0522D]/5 rounded-xl border border-[#A0522D]/20 focus:outline-none focus:ring-2 focus:ring-[#A0522D]/60" 
                            placeholder="Author Name" 
                            value={newTestimonial.name}
                            onChange={(e) => setNewTestimonial({...newTestimonial, name: e.target.value})}
                          />
                          <button 
                            onClick={handleAddTestimonial}
                            className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                          >
                            Add Testimonial
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="lg:col-span-2">
                      <div className="bg-white p-8 rounded-[2rem] border border-[#A0522D]/20 shadow-xl">
                        <h3 className="text-2xl font-serif italic text-[#A0522D] mb-8">Existing Testimonials</h3>
                        
                        {testimonials.length === 0 ? (
                          <div className="text-center py-20 bg-[#A0522D]/5/30 rounded-3xl border border-dashed border-[#A0522D]/30">
                            <Quote size={48} className="text-[#A0522D]/30 mx-auto mb-4" />
                            <p className="text-[#A0522D]/50 font-medium">No testimonials yet.</p>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {testimonials.map((test) => (
                              <div key={test.id} className="p-6 bg-[#A0522D]/5/50 rounded-3xl border border-[#A0522D]/20 relative group">
                                <p className="text-[#A0522D]/80 italic mb-4 pr-12">"{test.text}"</p>
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-xs">{test.name[0]}</div>
                                  <span className="font-bold text-[#A0522D] text-sm">{test.name}</span>
                                </div>
                                <button 
                                  onClick={() => handleDeleteTestimonial(test.id)}
                                  className="absolute top-6 right-6 p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Floating WhatsApp Button --- */}
      <motion.a
        href={WHATSAPP_CONFIG.groupLink}
        target="_blank"
        rel="noopener noreferrer"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.1 }}
        className="fixed bottom-8 right-8 z-50 w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center shadow-2xl animate-pulse-whatsapp cursor-pointer group"
      >
        <MessageCircle size={32} className="group-hover:rotate-12 transition-transform" />
      </motion.a>

      {/* --- Custom Styles for Infinite Scroll --- */}
      <style>{`
        @keyframes gradient-x {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient-x {
          background-size: 200% 200%;
          animation: gradient-x 15s ease infinite;
        }
        @keyframes scroll-infinite {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-scroll-infinite {
          display: flex;
          width: max-content;
          animation: scroll-infinite 30s linear infinite;
        }
        .animate-scroll-infinite:hover {
          animation-play-state: paused;
        }
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
