const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Replace emerald-900 with [#A0522D]
content = content.replace(/text-emerald-900/g, 'text-[#A0522D]');
content = content.replace(/bg-emerald-900/g, 'bg-[#A0522D]');
content = content.replace(/border-emerald-900/g, 'border-[#A0522D]');
content = content.replace(/shadow-emerald-900/g, 'shadow-[#A0522D]');

// Replace emerald-950 with [#A0522D] (or a darker shade, let's just use [#A0522D])
content = content.replace(/text-emerald-950/g, 'text-[#A0522D]');
content = content.replace(/bg-emerald-950/g, 'bg-[#A0522D]');

// Replace emerald-800 with [#A0522D]/80
content = content.replace(/text-emerald-800/g, 'text-[#A0522D]/80');
content = content.replace(/bg-emerald-800/g, 'bg-[#A0522D]/80');

// Replace emerald-700 with [#A0522D]/70
content = content.replace(/text-emerald-700/g, 'text-[#A0522D]/70');
content = content.replace(/bg-emerald-700/g, 'bg-[#A0522D]/70');

// Replace emerald-50 with [#A0522D]/5
content = content.replace(/bg-emerald-50/g, 'bg-[#A0522D]/5');
content = content.replace(/border-emerald-50/g, 'border-[#A0522D]/10');
content = content.replace(/text-emerald-50/g, 'text-[#A0522D]/10');

// Replace emerald-100 with [#A0522D]/10
content = content.replace(/bg-emerald-100/g, 'bg-[#A0522D]/10');
content = content.replace(/border-emerald-100/g, 'border-[#A0522D]/20');
content = content.replace(/text-emerald-100/g, 'text-[#A0522D]/20');

// Replace emerald-200 with [#A0522D]/20
content = content.replace(/bg-emerald-200/g, 'bg-[#A0522D]/20');
content = content.replace(/border-emerald-200/g, 'border-[#A0522D]/30');
content = content.replace(/text-emerald-200/g, 'text-[#A0522D]/30');

// Replace emerald-300 with [#A0522D]/30
content = content.replace(/text-emerald-300/g, 'text-[#A0522D]/40');

// Replace emerald-400 with [#A0522D]/40
content = content.replace(/text-emerald-400/g, 'text-[#A0522D]/50');
content = content.replace(/bg-emerald-400/g, 'bg-[#A0522D]/50');

// Replace emerald-500 with [#A0522D]/50
content = content.replace(/text-emerald-500/g, 'text-[#A0522D]/60');
content = content.replace(/bg-emerald-500/g, 'bg-[#A0522D]/60');

// Now, for Temple Gold (amber-600)
// The user wants stats and small icons to be amber-600.
// Currently, stats are:
// <p className="text-5xl font-serif italic text-[#A0522D]"><CountUp end={events.length} /></p>
// Let's change these specific stats to amber-600.
content = content.replace(/text-5xl font-serif italic text-\[#A0522D\]/g, 'text-5xl font-serif italic text-amber-600');
content = content.replace(/text-3xl font-serif italic text-\[#A0522D\]/g, 'text-3xl font-serif italic text-amber-600');

// Small icons are currently text-emerald-600 or text-emerald-100 etc.
// Let's replace text-emerald-600 with text-amber-600 for icons.
// Actually, text-emerald-600 is used for primary CTAs as well?
// Wait, primary CTAs are bg-emerald-600.
// text-emerald-600 is used for icons, subtitles, labels.
// Let's replace text-emerald-600 with text-amber-600.
content = content.replace(/text-emerald-600/g, 'text-amber-600');

// Let's make sure bg-emerald-600 stays bg-emerald-600 (Nature's Breath).
// But wait, what about hover:text-emerald-600?
content = content.replace(/hover:text-amber-600/g, 'hover:text-emerald-600'); // Revert hover text to emerald-600 for links

// Let's fix the specific icons:
// <Globe className="text-amber-600" size={24} />
// <Users className="text-amber-600" />
// <ClipboardList className="text-amber-600" />
// <ImageIcon className="text-amber-600" />
// <Plus className="text-amber-600" />
// <Award className="text-amber-600" />
// <Handshake className="text-amber-600" />
// <Quote className="text-amber-600" />

// Let's also check if there are any other emerald-600 that should be amber-600.
// "Join Now" button:
// <button className="px-12 py-6 bg-[#A0522D] text-white rounded-full font-black text-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] hover:bg-[#A0522D] transition-all flex items-center gap-4 group" onClick={() => setShowJoinModal(true)}>
// Wait, the Join Now button was bg-emerald-900 before.
// The user said: "Nature’s Breath (Emerald Green): #059669 (Tailwind emerald-600) Why: The heart of the movement. Use this for primary CTA buttons, success states, and the "Join Now" button."
// So the Join Now button should be bg-emerald-600.

fs.writeFileSync('src/App.tsx', content);
